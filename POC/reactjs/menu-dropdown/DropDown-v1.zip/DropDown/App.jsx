//My old Code

 import React, { Component } from 'react';
 import Admin  from './Admin';
import $ from 'jquery';
 
 class App extends Component {
      componentDidMount() {
     
  $('#test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });


   }
   
    
 
render() {
     return (
 <div className="container">  
              <link rel='stylesheet' type='text/css' href='scroll.css'/> 
              <div className="dropdown">
                  <button className="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span className="glyphicon glyphicon-list"></span></button>
   
              <ul className="dropdown-menu">
                  <li className="dropdown-submenu"><Admin/></li>
        
 </ul>
              </div>
 </div>
     )
   }
 }
 
 export default App;