import React,{Component} from 'react';



class Admin extends Component{

render(){
    return(

  <div>
         <link rel='stylesheet' type='text/css' href='scroll.css'/> 
        <a id="test" href="#">Admin <span className="glyphicon glyphicon-chevron-right"></span></a>
        <ul className="dropdown-menu">
          <li><a  href="#">UserRole</a></li>
          <li><a  href="#">Customer</a></li>
          <li><a  href="http://localhost:8082">Login</a></li>
        </ul>
      </div>
    )
}

}
export default Admin;