package com.npo;

public class InsertData {
	private String act_name;
	private String act_type ;
	private String file_type;
	public InsertData(String act_name, String act_type, String file_type) {
		
		this.act_name = act_name;
		this.act_type = act_type;
		this.file_type = file_type;
	}
	public String getAct_name() {
		return act_name;
	}
	public void setAct_name(String act_name) {
		this.act_name = act_name;
	}
	public String getAct_type() {
		return act_type;
	}
	public void setAct_type(String act_type) {
		this.act_type = act_type;
	}
	public String getFile_type() {
		return file_type;
	}
	public void setFile_type(String file_type) {
		this.file_type = file_type;
	}

	

}
