package com.npo;

import java.util.ArrayList;

public class FileDetails
{
  String activity_name;
  String activity_type;
  ArrayList<Files> file;
  
  public String getActivity_name()
  {
    return this.activity_name;
  }
  
  public void setActivity_name(String activity_name)
  {
    this.activity_name = activity_name;
  }
  
  public String getActivity_type()
  {
    return this.activity_type;
  }
  
  public void setActivity_type(String activity_type)
  {
    this.activity_type = activity_type;
  }
  
  public ArrayList<Files> getFile()
  {
    return this.file;
  }
  
  public void setFile(ArrayList<Files> file)
  {
    this.file = file;
  }
  
  public String toString()
  {
    return 
      "FileDetails [activity_name=" + this.activity_name + ", activity_type=" + this.activity_type + ", file=" + this.file + "]";
  }
}
