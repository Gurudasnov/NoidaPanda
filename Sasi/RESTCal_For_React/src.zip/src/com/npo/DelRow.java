package com.npo;

public class DelRow {
	String act_name;

	public String getAct_name() {
		return act_name;
	}

	public void setAct_name(String act_name) {
		this.act_name = act_name;
	}
}
