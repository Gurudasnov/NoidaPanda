package com.npo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.Model.AttributeEntries;
import com.Model.Data;
import com.Model.DeleteStatus;
import com.Model.Sdata;
import com.Model.Udata;
import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

@Path("Transaction")
public class BlobTransactions {
	public void ReadJsonFileFromCassandra(Session session, String actName, String actType, String fileType) throws IOException
	{
		       //Reading schema file
				PreparedStatement ps = session.prepare("select file from dataAccess.data where act_name = ? AND act_type = ? AND file_type=?");
				BoundStatement boundStatement = new BoundStatement(ps);

				ResultSet rs = session.execute(boundStatement.bind(actName,actType,fileType));
				System.out.println("printing result set"+rs.toString());

				ByteBuffer bufferFile = null;
				File json_file;
				
				if(fileType.compareTo("schema") == 0)
				{
					json_file = new File("/opt/resources/json_files/schema.json");
					//json_file = new File("C:/schema.json");
				}
				else
				{
					json_file = new File("/opt/resources/json_files/data.json");
					//json_file = new File("C:/data.json");
				}
				if(!rs.isExhausted()){  
					
					Row row = rs.one();
					bufferFile = row.getBytes("file"); 
		    		FileChannel wChannel = new FileOutputStream(json_file, false).getChannel();
		    		wChannel.write(bufferFile);
		    		wChannel.close();
				} 
	}
	
	@POST
	@Path("select/{data}")
	@Produces({"application/json"}) 
	
	public Response FileSelection(@PathParam("data") String jsonInput)
	{
		Session session;
		
		Gson gson = new Gson();  
		SelectData selData = gson.fromJson(jsonInput, SelectData.class); 
		System.out.println("Json input:: "+jsonInput);
		
		Cluster cluster = Cluster.builder().addContactPoint("192.168.104.63")
				.withCredentials("cassandra", "cassandra").build();
		String activity_type = selData.getActivity_type();
		session = cluster.connect();
		PreparedStatement ps = session.prepare("select * from dataaccess.data where act_type = ? allow filtering");
		BoundStatement boundStatement = new BoundStatement(ps);
		ResultSet rs = session.execute(boundStatement.bind(new Object[]{activity_type}));
		
		List<AttributeEntries> attributeEntryList = new ArrayList<AttributeEntries>();
		AttributeEntries attentries = null;

		while(!rs.isExhausted()){  
			Row row = rs.one();
			String rw = row.toString();
			rw = rw.substring(rw.indexOf("[")+1,rw.indexOf("]"));
			List<String> attList = Arrays.asList(rw.split(","));
			int numOfAttributes = 0;
			for(String str: attList)
			{
				if(numOfAttributes == 0)
				{
					attentries = new AttributeEntries();
					attentries.setAct_name(str);
				}
				if(numOfAttributes == 1)
					//attentries.setAct_type(str);
				if(numOfAttributes == 2)
					//attentries.setFile(str);
				if(numOfAttributes == 3)
				{
					numOfAttributes=0;
					//attentries.setFile_type(str);
				}
				numOfAttributes++;
			}
			attributeEntryList.add(attentries);
		} 
		System.out.println("Before returning");
		return Response.ok(attributeEntryList).header("Access-Control-Allow-Origin", "*").build();  
	}
	
	
	@POST
	@Path("insert/{data}")
	//@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON) 

	public Response JsonFileInsertion(FileDetails fd)
	  {
	    System.out.println("file details: " + fd.toString());
	    
	    Response res = null;
	    FileInputStream fileInputStream = null;
	    
	    Cluster cluster = Cluster.builder().addContactPoint("192.168.104.63").withPort(9042)
	      .withCredentials("cassandra", "cassandra").build();
	    System.out.println("Connecting to Cassandra");
	    Session session = cluster.connect();
	    ArrayList<Status> ae = new ArrayList();
	    String activity_name = fd.getActivity_name();
	    String activity_type = fd.getActivity_type();
	    ArrayList<Files> list_file = fd.getFile();
	    for (Files temp : list_file)
	    {
	      String filename = temp.getFile();
	      String template_type = temp.getTemplate_type();
	      File file = new File(filename);
	      if (file.exists())
	      {
	        System.out.println("File Found");
	        byte[] bFile = new byte[(int)file.length()];
	        try
	        {
	          fileInputStream = new FileInputStream(file);
	          fileInputStream.read(bFile);
	          fileInputStream.close();
	        }
	        catch (FileNotFoundException e)
	        {
	          e.printStackTrace();
	        }
	        catch (IOException e)
	        {
	          e.printStackTrace();
	        }
	        ByteBuffer buffer = ByteBuffer.wrap(bFile);
	        System.out.println("Insertion started");
	        PreparedStatement ps = session.prepare("INSERT INTO datafile.data (act_name, act_type,file_type,file) VALUES (?,?,?,?)");
	        BoundStatement boundStatement = new BoundStatement(ps);
	        session.execute(boundStatement.bind(new Object[] { activity_name, activity_type, template_type, buffer }));
	        System.out.println(filename + "Inserted file as blob into cassandra");
	        Status st = new Status();
	        st.setFile_name(filename);
	        st.setInsertion_status(true);
	        ae.add(st);
	      }
	      else
	      {
	        Status st = new Status();
	        st.setFile_name(filename);
	        st.setInsertion_status(false);
	        ae.add(st);
	      }
	    }
	    return Response.ok(ae).header("Access-Control-Allow-Origin", "*").build();
	  }
	
	
	@POST
	@Path("delete/{data}")
	@Produces({"application/json"}) 
	
	public Response FileDeletion(@PathParam("data") String jsonInput)
	{
		Session session;
		
		Gson gson = new Gson();  
		DelRow dr = gson.fromJson(jsonInput, DelRow.class); 
		System.out.println("Json input:: "+jsonInput);
		
		
		
		
		Cluster cluster = Cluster.builder().addContactPoint("192.168.104.62")
				.withCredentials("cassandra", "cassandra").build();
		String delAct = dr.getAct_name();
		session = cluster.connect();
		//PreparedStatement ps = session.prepare("select * from dataaccess.data where act_type = ? allow filtering");
		PreparedStatement ps = session.prepare("DELETE FROM dataAccess.data where act_name=?");
		BoundStatement boundStatement = new BoundStatement(ps);
		//ResultSet rs = session.execute(boundStatement.bind(new Object[]{activity_type}));
		ResultSet rs = session.execute(boundStatement.bind(new Object[]{delAct}));
		DeleteStatus ds = new DeleteStatus();
		if(!rs.isExhausted())
		{
			ds.setStatus("not Ok");
		}
		else
		{
			ds.setStatus("Ok");
		}
		
		
		System.out.println("deleted a row based on the entry"+rs.toString()); 
		return Response.ok(ds).header("Access-Control-Allow-Origin", "*").build();
	}
	
	@GET
	@Path("createkeyspace")
	public void CreateKeySpaceDataaccess() throws IOException
	{
		Session session;
		String filename="";
		
		Cluster cluster = Cluster.builder().addContactPoint("192.168.104.62")
				.withCredentials("cassandra", "cassandra")
				.build();
		
		session = cluster.connect();
		
		String query = "CREATE KEYSPACE IF NOT EXISTS dataaccess WITH replication "
	    		   + "= {'class':'SimpleStrategy', 'replication_factor':3}; ";
	    	
	     session.execute(query);
	     System.out.println("Keyspace dataaccess created"); 

	    session.close();          		
	}
	
	@GET
	@Path("dropkeyspace")
	public void DeleteKeySpaceDataaccess() throws IOException
	{
		Session session;
		String filename="";
		
		Cluster cluster = Cluster.builder().addContactPoint("192.168.104.62")
				.withCredentials("cassandra", "cassandra")
				.build();
		
		session = cluster.connect();
		
		String query = "DROP KEYSPACE dataaccess";
	     
	    session.execute(query);
	    System.out.println("Keyspace dataaccess deleted"); 

	    session.close();          		
	}
	
	@GET
	@Path("createtable")
	public void CreateTableData() throws IOException
	{
		Session session;
		String filename="";
		
		Cluster cluster = Cluster.builder().addContactPoint("192.168.104.62")
				.withCredentials("cassandra", "cassandra")
				.build();
		
		session = cluster.connect();
		
		session.execute("USE dataaccess");
		 
		session.execute("CREATE TABLE IF NOT EXISTS dataaccess.data (" +
		         "act_name text, " +
		         "act_type text,"
		         + " " +
		         "file_type text, " +
		         "file blob, "  + 
                "PRIMARY KEY (act_name, act_type, file_type))" + //); 
		        "WITH default_time_to_live = 600 " +
                "AND GC_GRACE_SECONDS = 60 " + 
                "AND compaction = {'class' : 'org.apache.cassandra.db.compaction.TimeWindowCompactionStrategy', 'enabled' : 'true', 'tombstone_compaction_interval': '600', 'compaction_window_size': '2', 'compaction_window_unit': 'MINUTES', 'min_threshold': '2'}"); 
		System.out.println("Table data created"); 
	    session.close();          		
	}
	
	    @GET
		@Path("insertschema")
		@Consumes(MediaType.APPLICATION_JSON)
		public void InsertSchemaJson() throws IOException
		{
			Session session;
			String filename="";
			
			 Cluster cluster = Cluster.builder().addContactPoint("192.168.104.62")
					.withCredentials("cassandra", "cassandra")
					.build();
			
			 session = cluster.connect();
			
			 session.execute("USE dataaccess");
			 
			 FileInputStream fileInputStream = null; 
		        
			 File file = new File("/opt/resources/json_input_files/schema.json");
			
			 //File file = new File("C:/json_input_files/schema.json");
		     byte[] bFile = new byte[(int) file.length()]; 
			 
		     fileInputStream = new FileInputStream(file); 
		     fileInputStream.read(bFile); 
		     fileInputStream.close(); 
		     
		     ByteBuffer buffer =ByteBuffer.wrap(bFile);
		       
		     String templateName = "template1";
		     String actType = "site creation";
		     String fileType = "schema";
		     
		     PreparedStatement ps = session.prepare("INSERT INTO dataaccess.data (act_name, act_type, file_type, file) VALUES (?,?,?,?)");
		     BoundStatement boundStatement = new BoundStatement(ps);
		     session.execute(boundStatement.bind(templateName, actType, fileType, buffer));
		     System.out.println("Inserted JSON schema into cassandra"); 
		        		
		}
		
	/*
	@POST
	@Path("insertschemaF")
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public Response InsertSchemaWithFormJson(@FormDataParam("file") InputStream fileInputStream,
            @FormDataParam("file") FormDataContentDisposition fileMetaData,
            @FormDataParam("templateName") String templateName,
            @FormDataParam("actType") String actType,
            @FormDataParam("fileType") String fileType) throws IOException
	{
		Session session;
		String filename="";
		
		Cluster cluster = Cluster.builder().addContactPoint("192.168.104.62")
				.withCredentials("cassandra", "cassandra")
				.build();
		
		session = cluster.connect();
		
		session.execute("USE dataaccess");
		 
		 byte[] bFile = new byte[1024]; 
		
	     fileInputStream.read(bFile);
	     ByteBuffer buffer =ByteBuffer.wrap(bFile);
	     
	     PreparedStatement ps = session.prepare("INSERT INTO dataaccess.data (act_name, act_type, file_type, file) VALUES (?,?,?,?)");
	     BoundStatement boundStatement = new BoundStatement(ps);
	     session.execute(boundStatement.bind(templateName, actType, fileType, buffer));
	     System.out.println("Inserted JSON schema into cassandra"); 
	     return Response.ok().build();   		
	}
	*/
	    
	@GET
	@Path("insertdata")
	@Consumes(MediaType.APPLICATION_JSON)
	public void InsertDataJson() throws IOException
	{
		Session session;
		String filename="";
		
		Cluster cluster = Cluster.builder().addContactPoint("192.168.104.62")
				.withCredentials("cassandra", "cassandra")
				.build();
				
		/*
		Cluster cluster = Cluster.builder().addContactPoint("localhost")
				//.withCredentials("cassandra", "cassandra")
				.build();
				*/
		session = cluster.connect();
		
		session.execute("USE dataaccess");
		 
		 FileInputStream fileInputStream = null; 
	        
		 File file = new File("/opt/resources/json_input_files/data.json");
		 //File file = new File("C:/json_input_files/data.json");
	     byte[] bFile = new byte[(int) file.length()]; 
	     fileInputStream = new FileInputStream(file); 
	     fileInputStream.read(bFile); 
	     fileInputStream.close(); 
	     ByteBuffer buffer =ByteBuffer.wrap(bFile);
	         
	     String templateName = "template1";
	     String actType = "site creation";
	     String fileType = "data";
	     PreparedStatement ps = session.prepare("INSERT INTO dataaccess.data (act_name, act_type, file_type, file) VALUES (?,?,?,?)");
	     BoundStatement boundStatement = new BoundStatement(ps);
	     session.execute(boundStatement.bind(templateName, actType, fileType, buffer));
	     System.out.println("Inserted JSON data into cassandra"); 
	}
	@GET
	@Path("execute")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON) 
	public void TemplateExecution() throws IOException, ParserConfigurationException, SAXException
	{
		Session session;
		String filename="";
		
		Cluster cluster = Cluster.builder().addContactPoint("192.168.104.62")
				.withCredentials("cassandra", "cassandra")
				.build();

		session = cluster.connect();
		
		String actName = "template1";
	    String actType = "site creation";
	    String fileTypeSchema = "schema";
	    String fileTypeData = "data";
	    
	    //Schema and Data file read from Cassandra and stored in /opt/resources/json_files- schema.json and data.json
	    ReadJsonFileFromCassandra(session, actName, actType, fileTypeSchema);
	    ReadJsonFileFromCassandra(session, actName, actType, fileTypeData);
		
	    //Call validation code
	    Udata userData = (Udata) ParsingService.parseData("/opt/resources/json_files/data.json", Udata.class);
		Sdata schemaData = (Sdata) ParsingService.parseData("/opt/resources/json_files/schema.json", Sdata.class);
		
	    Boolean b = ValidateRange.validateUserDataByRange(userData, schemaData); 
	    System.out.println("Result of ValidateUserDataByRange: " + b);
	    
	    if(b ==true)
	    {
	    	Data usData = (Data) ParsingService.parseData("/opt/resources/json_files/data.json", Data.class);

	    	Data snapshotData = CreateXmlObject.createTemplateObject();
			Data data = mergeTemplateWithUserData.mergeWithSnapshot(usData, snapshotData);
			CreateTemplate.create("/opt/resources/xml_files/createTemplate.xml",data);

	    }
	}
	public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException {
		BlobTransactions bt = new BlobTransactions();
		bt.TemplateExecution();
	}
}