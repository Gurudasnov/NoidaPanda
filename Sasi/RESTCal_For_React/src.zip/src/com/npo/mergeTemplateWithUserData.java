package com.npo;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.Model.Data;
import com.Model.DataAttribute;
import com.Model.DataMOs;
import com.npo.ParsingService;

public class mergeTemplateWithUserData {
	public static Data mergeWithSnapshot(Data userData,Data snapshotData) {

		List<String> MoNameList = new ArrayList<>();
		List<DataAttribute> daList  = new ArrayList<>();
		List<DataMOs>  dataMolist = new ArrayList<>();
		if (snapshotData != null) {
			int lengthuserData= userData.getMos().size();
			int lengthSnapshotData = snapshotData.getMos().size();
			for (int i = 0; i < lengthuserData; i++) {
				//System.out.println(userData.getMos().get(i).getMO_name());
				MoNameList.add(userData.getMos().get(i).getMO_name());
				dataMolist.add(userData.getMos().get(i));
			}
			for (int i = 0; i < lengthSnapshotData; i++) {
				String moName = snapshotData.getMos().get(i).getMO_name();
				//System.out.println(moName);
				if(!(MoNameList.contains(moName))){
					dataMolist.add(snapshotData.getMos().get(i));
				}else {
					DataMOs dmo3=null;
					DataMOs dmo = snapshotData.getMos().get(i);
					for (int j = 0; j < userData.getMos().size(); j++) {
						
							DataMOs dmo1 = userData.getMos().get(j);
							if (dmo1.getMO_name().equals(dmo.getMO_name())) {
								System.out.println("1111111");
								dmo3 =addAttribute(dmo1, dmo);
								dataMolist.remove(dmo1);
								dataMolist.add(dmo3);
							}
							
							
					}
					
				}
			}
			
			
			userData.setMos((ArrayList<DataMOs>) dataMolist);
		}else{
			return userData;
		}
		
		System.out.println(userData.getMos().size());
		
		
	return userData;
	}
		private static DataMOs addAttribute(DataMOs dataMOs, DataMOs dataMOs2) {
		Set<	DataAttribute> d1 = new HashSet<>(dataMOs.getAttributes());
		Set<DataAttribute> d2 =new HashSet<>(dataMOs2.getAttributes());
		
		d1.addAll(d2);
			List<DataAttribute> daList = new ArrayList<>(d1);
			DataMOs dmo = new DataMOs();
			dmo.setMO_name(dataMOs.getMO_name());
			dmo.setAttributes(daList);
			return dmo;
			
		
		}
		private static List<DataMOs> addMO(DataMOs dataMOs, DataMOs dataMOs2) {
		

            List<DataMOs> listDataMo = new ArrayList<>();
            listDataMo.add(dataMOs);
            listDataMo.add(dataMOs2);
			return  listDataMo;
	}

}
