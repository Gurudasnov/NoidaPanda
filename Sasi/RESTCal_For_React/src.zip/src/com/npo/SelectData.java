package com.npo;

public class SelectData {
	String activity_type;

	public String getActivity_type() {
		return activity_type;
	}

	public void setActivity_type(String activity_type) {
		this.activity_type = activity_type;
	}
}
