package com.npo;

public class Status
{
  String file_name;
  boolean insertion_status;
  
  public boolean isInsertion_status()
  {
    return this.insertion_status;
  }
  
  public void setInsertion_status(boolean insertion_status)
  {
    this.insertion_status = insertion_status;
  }
  
  public String getFile_name()
  {
    return this.file_name;
  }
  
  public void setFile_name(String file_name)
  {
    this.file_name = file_name;
  }
}
