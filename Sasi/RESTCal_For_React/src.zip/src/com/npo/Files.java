package com.npo;

public class Files
{
  String file;
  String template_type;
  
  public String getFile()
  {
    return this.file;
  }
  
  public void setFile(String file)
  {
    this.file = file;
  }
  
  public String getTemplate_type()
  {
    return this.template_type;
  }
  
  public void setTemplate_type(String template_type)
  {
    this.template_type = template_type;
  }
  
  public String toString()
  {
    return "Files [file=" + this.file + ", template_type=" + this.template_type + "]";
  }
}
