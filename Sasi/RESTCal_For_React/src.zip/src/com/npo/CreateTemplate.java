package com.npo;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import com.Model.Data;
import org.w3c.dom.Element;

public class CreateTemplate {
	public static void create(String createTemplateFileName,Data userData) {
		 try {
			 //Data userData=(Data) ParsingService.parseData("New-data.json", Data.class);
				
			 DocumentBuilderFactory dbFactory =
			         DocumentBuilderFactory.newInstance();
			         DocumentBuilder dBuilder = 
			            dbFactory.newDocumentBuilder();
			         Document doc = dBuilder.newDocument();
			         
			         Element rootElement = doc.createElement("createTemplate");
			         rootElement.setAttribute("name", "new output");
			         rootElement.setAttribute("creationDate", "2017-06-09 10:31:01.499 +0530");
			         rootElement.setAttribute("originator", "");
			         rootElement.setAttribute("description", "");
			         
			         doc.appendChild(rootElement);
			         Element MoName =null;
					for (int i = 0; i < userData.getMos().size(); i++) {
						 MoName = doc.createElement(userData.getMos().get(i).getMO_name());
				         MoName.setAttribute("ID", userData.getMos().get(i).getMO_name());
				         MoName.setAttribute("Method", "create");
				         rootElement.appendChild(MoName);
				         Element Attribute= doc.createElement("Attributes");
				         for (int j = 0; j < userData.getMos().get(i).getAttributes().size(); j++) {
				        	 
					         Element attr = doc.createElement(userData.getMos().get(i).getAttributes().get(j).getAttribute_name());
					         attr.appendChild(
					         doc.createTextNode(""+userData.getMos().get(i).getAttributes().get(j).getValues()));
					         Attribute.appendChild(attr);
					         
						}
				         MoName.appendChild(Attribute);	
					}
			        
						
			         TransformerFactory transformerFactory =
			                 TransformerFactory.newInstance();
			                 Transformer transformer =
			                 transformerFactory.newTransformer();
			                 DOMSource source = new DOMSource(doc);
			                 StreamResult result =
			                 new StreamResult(new File("/opt/resources/xml_files/output.xml"));
			                 transformer.transform(source, result);
			                 // Output to console for testing
			                 StreamResult consoleResult =
			                 new StreamResult(System.out);
			                 transformer.transform(source, consoleResult);
			              } catch (Exception e) {
			                 e.printStackTrace();
			              }
		 
	}

}
