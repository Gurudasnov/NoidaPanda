

package com.npo;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.jdom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.Model.Data;
import com.Model.DataAttribute;
import com.Model.DataMOs;
import com.npo.ParsingService;

public class CreateXmlObject {
public static Data createTemplateObject() throws ParserConfigurationException, SAXException, IOException {

Data data=new Data();
DataMOs dmo=null;
DataAttribute datt =null; 

List<DataMOs> ldmo = new ArrayList<>();
List<DataAttribute> ldatt = new ArrayList<>();
	File inputFile = new File("/opt/resources/xml_files/createTemplate.xml");
    DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.parse(inputFile );
	for (int i = 1; i < doc.getDocumentElement().getChildNodes().getLength(); i++) {
		
		if (!doc.getDocumentElement().getChildNodes().item(i).getNodeName().equals("#text")) {
			//System.out.println(doc.getDocumentElement().getChildNodes().item(i).getNodeName());
			String nodeNameMos = doc.getDocumentElement().getChildNodes().item(i).getNodeName();
	 // System.out.println("l1"+doc.getDocumentElement().getChildNodes().item(i).getChildNodes().getLength());
			for (int j = 1; j < doc.getDocumentElement().getChildNodes().item(i).getChildNodes().getLength(); j++) {
			//System.out.println("l2"+doc.getDocumentElement().getChildNodes().item(i).getNodeName());
			
			
			//System.out.println("mmmm"+doc.getDocumentElement().getChildNodes().item(i).getChildNodes().item(j).getChildNodes().getLength());
				for (int j2 = 1; j2 < doc.getDocumentElement().getChildNodes().item(i).getChildNodes().item(j).getChildNodes().getLength(); j2++) {
					
					//System.out.println(doc.getDocumentElement().getChildNodes().item(i).getChildNodes().item(j).getChildNodes().item(j2).getNodeName());
					String nodeNameAttr = doc.getDocumentElement().getChildNodes().item(i).getChildNodes().item(j).getChildNodes().item(j2).getNodeName();
					
				if(((doc.getDocumentElement().getChildNodes().item(i).getChildNodes().item(j).getChildNodes().item(j2).getNodeName()).equals("#text"))){
					//System.out.print(doc.getDocumentElement().getChildNodes().item(i).getChildNodes().item(j).getChildNodes().item(j2).getNodeName());
				   // System.out.println(doc.getDocumentElement().getChildNodes().item(i).getChildNodes().item(j).getChildNodes().item(j2).getTextContent());
				
				}else{
					String attrName = doc.getDocumentElement().getChildNodes().item(i).getChildNodes().item(j).getChildNodes().item(j2).getNodeName();
					Object attrVlaue = doc.getDocumentElement().getChildNodes().item(i).getChildNodes().item(j).getChildNodes().item(j2).getTextContent();
				    datt =	new DataAttribute();
					datt.setAttribute_name(attrName);
					datt.setValues(attrVlaue);
					
					
					
				}
				ldatt.add(datt);
			
				}
				//System.out.println(ldatt);
				//System.out.println(ldatt.size());
				//System.out.println(doc.getDocumentElement().getChildNodes().item(i).getNodeName());
				
				
			//System.out.println(ldatt.get(1).getAttribute_name());
	}
			dmo=new DataMOs();
			//System.out.println(nodeNameMos);
			dmo.setMO_name(nodeNameMos);
			//System.out.println(ldatt);
			dmo.setAttributes(ldatt);
			ldmo.add(dmo);
	//	System.out.println("----"+ldmo.get(0).getMO_name());
		//System.out.println(ldmo.get(0).getAttributes().get(0).getAttribute_name());
		//System.out.println(ldmo.get(0).getAttributes().get(0).getAttribute_name());
		//System.out.println(dmo.getAttributes().get(0).getAttribute_name());
	}
		
	}	
	
	data.setMos((ArrayList<DataMOs>) ldmo);
	//System.out.println(data.getMos().get(1).getAttributes());
	return data;
}	
}

