package com.Model;

import java.util.List;

public class AttributeList {
	public List<AttributeEntries> AE;
}
