package com.Model;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

@XmlRootElement(namespace = "com.Model.Data")
public class DataMOs implements Serializable {
private String MO_name;
	
	private List<DataAttribute> attributes;
	@XmlAttribute
	public String getMO_name() {
		return MO_name;
	}
	public void setMO_name(String mO_name) {
		this.MO_name = mO_name;
	}
	@XmlElement
	public List<DataAttribute> getAttributes() {
		return attributes;
	}
	
	public void setAttributes(List<DataAttribute> attributes) {
		this.attributes = attributes;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return MO_name.hashCode();
	}
@Override
	public boolean equals(Object obj) {
	if (obj == this) return true;
    if (!(obj instanceof DataAttribute)) {
        return false;
    }
    DataMOs user = (DataMOs) obj;
    return  Objects.equals(MO_name, user.getMO_name());
	}

}
