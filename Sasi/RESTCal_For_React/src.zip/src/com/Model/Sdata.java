package com.Model;

import java.util.List;

public class Sdata {
	private List<SMOs> MOs;

	public List<SMOs> getMOs() {
		return MOs;
	}

	public void setMOs(List<SMOs> mOs) {
		MOs = mOs;
	}

	
}
