package com.Model;

public class DataAttribute {
private String attribute_name;
private Object value;
public String getAttribute_name() {
	return attribute_name;
}
public void setAttribute_name(String attribute_name) {
	this.attribute_name = attribute_name;
}
public Object getValues() {
	return value;
}
public void setValues(Object values) {
	this.value = values;
}

}
