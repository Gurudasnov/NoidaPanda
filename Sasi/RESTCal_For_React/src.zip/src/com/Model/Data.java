package com.Model;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Data implements Serializable  {
	private ArrayList<DataMOs> MOs;

	public Data() {
		// TODO Auto-generated constructor stub
	}
	@XmlElement
	public List<DataMOs> getMos() {
		return MOs;
	}

	@XmlElementWrapper(name = "MoList")
	@XmlElement(name = "Mos")
	public void setMos(ArrayList<DataMOs> mos) {
		MOs = mos;
	}
	public int hashCode() {
		// TODO Auto-generated method stub
		return MOs.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
	if (obj == this) return true;
	if (!(obj instanceof Data)) {
	    return false;
	}
	Data user = (Data) obj;
	return  Objects.equals(MOs, user.MOs);
	}



}
