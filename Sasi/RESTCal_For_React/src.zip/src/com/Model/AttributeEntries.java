package com.Model;

public class AttributeEntries {

	//private String act_type;
	private String act_name;
	//private String file_type;
	//private String file;
	
//	public String getAct_type() {
//		return act_type;
//	}
//	public void setAct_type(String act_type) {
//		this.act_type = act_type;
	//}
	public String getAct_name() {
		return act_name;
	}
	public void setAct_name(String act_name) {
		this.act_name = act_name;
	}
//	public String getFile_type() {
//		return file_type;
//	}
//	public void setFile_type(String file_type) {
//		this.file_type = file_type;
//	}
//	public String getFile() {
//		return file;
//	}
//	public void setFile(String file) {
//		this.file = file;
//	}
	
}
