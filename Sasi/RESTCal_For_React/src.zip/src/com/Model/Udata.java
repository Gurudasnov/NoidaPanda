package com.Model;

import java.util.ArrayList;
import java.util.List;

public class Udata {
private ArrayList<UMOs> MOs;

public List<UMOs> getMos() {
	return MOs;
}

public void setMos(ArrayList<UMOs> mos) {
	MOs = mos;
}

}
