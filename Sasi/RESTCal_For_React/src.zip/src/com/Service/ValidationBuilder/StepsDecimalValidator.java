package com.Service.ValidationBuilder;

public class StepsDecimalValidator implements IRangeValidator{

	@Override
	public boolean isValid(String rangeSchema, Object value) {
		System.out.println("StepsDecimalValidator --- isValid()");
		 return false;
	}

}
