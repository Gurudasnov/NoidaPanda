package com.Service.ValidationBuilder;

public interface IRangeValidator {
	
	
	boolean isValid (String rangeSchema, Object value);
}
