package com.fileUploader;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadBase;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.google.gson.Gson;
import com.fileUploader.SelectData;

public class getFileFromReact
  extends HttpServlet
{
  private static final long serialVersionUID = 1L;
  private static final String UPLOAD_DIRECTORY = "/opt/EAP-7.1.0/sunil";
  private String filePath = "";
  private String failedResult = "";
  
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {}
  
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
	String jsonInput=request.getQueryString(); 
	String jsonInput1=jsonInput.replaceAll("%20","\\s");
	System.out.println("bjhdbfgdjgb"+jsonInput1);
	String jsonInput2=jsonInput1.replaceAll("%22","\"");
	System.out.println("bjhdbfgdjgb"+jsonInput2);
	
	Gson gson = new Gson();  
	SelectData selData = gson.fromJson(jsonInput2, SelectData.class); 
	System.out.println("Json input:: "+request.getQueryString());
	System.out.println("activity_Name"+selData.getActivity_name()+"\nactivity_Type:"+selData.getActivity_type()+"\nfile_Type"+selData.getFile_Type());
    try
    {
      System.out.println(request.getQueryString());
      System.out.println("In Post Method.");
      if (!ServletFileUpload.isMultipartContent(request))
      {
        PrintWriter writer = response.getWriter();
        response.setStatus(400);
        writer.println("{\"msg\": \"Request does not contain upload data\"}");
        System.out.println("Request does not contain upload data.");
        writer.flush();
        return;
      }
      System.out.println("MultipartContent detected.");
      DiskFileItemFactory factory = new DiskFileItemFactory();
      factory.setSizeThreshold(3145728);
      factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
      ServletFileUpload upload = new ServletFileUpload(factory);
      upload.setFileSizeMax(41943040L);
      upload.setSizeMax(52428800L);
      
      File uploadDir = new File("/opt/EAP-7.1.0/sunil");
      if (!uploadDir.exists()) {
        uploadDir.mkdir();
      }
      try
      {
        List formItems = upload.parseRequest(request);
        System.out.println("List of form data");
        Iterator iter = formItems.iterator();
        while (iter.hasNext())
        {
          FileItem item = (FileItem)iter.next();
          if (!item.isFormField())
          {
            String fileName = new File(item.getName()).getName();
          
            this.filePath = ("/opt/EAP-7.1.0/sunil" + File.separator + fileName + new Date().getTime());
            
            File storeFile = new File(this.filePath);
            
            item.write(storeFile);
          }
        }
        if ("".equals(this.failedResult))
        {
          response.setStatus(201);
          PrintWriter writer = response.getWriter();
          writer.println("{\"msg\": \"Upload has been done successfully!\"}");
          System.out.println("Upload has been done successfully!");
          writer.flush();
          return;
        }
        request.setAttribute("message", "<h2>The below records failed to insert:</h2> <br/><table border=0><tr><td>  MAKE </td> <td> MODEL</td><td>   GT  </td><td>  LT</td>   <td>RESOURCE_PATH</td></tr>" + this.failedResult + "</table>");
      }
      catch (Exception ex)
      {
        request.setAttribute("message", "There was an error: " + ex.getMessage());
      }
      PrintWriter writer = response.getWriter();
    }
    catch (Exception e)
    {
      System.out.println("error " + e);
    }
    PrintWriter writer = response.getWriter();
    response.setStatus(500);
    
    writer.println("{\"msg\": \"Failed to parse the file!\"}");
    System.out.println("Failed to parse the file!");
    writer.flush();
  }
}
