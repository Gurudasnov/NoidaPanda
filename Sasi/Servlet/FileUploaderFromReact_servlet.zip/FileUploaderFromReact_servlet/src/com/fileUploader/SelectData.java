package com.fileUploader;

public class SelectData {
	String activity_type;
	String activity_name;
	String file_Type;
	public String getActivity_type() {
		return activity_type;
	}
	public void setActivity_type(String activity_type) {
		this.activity_type = activity_type;
	}
	public String getActivity_name() {
		return activity_name;
	}
	public void setActivity_name(String activity_name) {
		this.activity_name = activity_name;
	}
	public String getFile_Type() {
		return file_Type;
	}
	public void setFile_Type(String file_Type) {
		this.file_Type = file_Type;
	}

	

}
