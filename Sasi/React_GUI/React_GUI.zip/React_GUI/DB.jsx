import React from 'react';
import FileDB from './filedb.jsx';
import FileChooser from './filechooser.jsx';
import UpLoad from './upload.jsx';
import TemplateList from './TemplateList.jsx';
import TemplateDetailsList from './TemplateDetailsList.jsx';
{/* import Selection from './selection.jsx'; */}


class DB extends React.Component
{
	constructor(props){
		super(props);
		this.state={num:0};
				}
	
	updateNum(event){
		this.setState({num:event.target.value});    
	}	
	  
	
	render(){
		var file=[];
		for(var i=0;i<this.state.num;i++){
			file.push(<FileChooser key={i} />);
			}
			
		var uploadfile=[];
		if(this.state.num != 0)
		{
		uploadfile.push(<UpLoad />); 
		}
		
		return(
	
		<div>
				<div className = "center" >
				  

				  <label> <h4> Select Activity &nbsp;&nbsp;</h4></label>
				  <div className="selectWrapper">
				  
				 <select id="list" name="list" className="form-control"  onChange={this.updateNum.bind(this)} >
						<option value="0" > select </option>
						<option value="1" > Site Creation </option>
						<option value="2" > Carrier Addition </option>
						<option value="3" > Sector Addition </option>
				  </select> 
			
				  
				  </div>
				  
				  
									
				</div>			
				<div className="left" >
				<div id="appear" >
					<TemplateList num={this.state.num}/>
				</div>
				</div>
				<br/>
				
				<div className = "spacing">
				<div className = "border">

				
					<br/>
					<br/>
					<br/>
					{/* <TemplateDetailsList num={this.state.num}/> */}

					{/*<TemplateDetailsList list={this.state.num}/>*/}
				
			        
					<br/>
				
				</div>
				</div>	
				
		
		</div>
		);
	}
	
}


export default DB;
