import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Modal from './Modal.jsx';
import FileChooser from './filechooser.jsx';
import UpLoad from './upload.jsx';
import UpLoad1 from './upload1.jsx';
import UpLoad2 from './upload2.jsx'; 
import $ from 'jquery';

class TemplateList extends Component {

	constructor(props) {
		super(props);
		this.state = { isOpen: false, list: '' };
		/* this.state = {list:''}; */
		this.toggleModal = this.toggleModal.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.state = { items: [], jsonOutput: [] };
		var items1;
		var selectedOptionVal;
		var numForVerification = 0;
		var list;
		var deleteStatus='not Ok';

		{/* this.state = {
			list:''			
			};
		*/	}
	}


	handleChange(event) {
		this.setState({ list: event.target.value });
		
	}

	toggleModal() {
		this.setState({ isOpen: !this.state.isOpen });
	}

	/* toggleModal() {
	this.setState(prevState =>({
	  isOpen: !prevState.isOpen
	}));
	} */

	/* onIndexChanged (indexChanged) {
	this.setState({index: indexChanged})
	} */
	selectData() {
		var component = this;
		
		var activityTypeVar = "";
		/* var items;
		var finData; */
		if (this.props.num == 1) { activityTypeVar = "site creation" };
		if (this.props.num == 2) { activityTypeVar = "Carrier Addition" };
		if (this.props.num == 3) { activityTypeVar = "Sector Addition" };

		var markers = { "activity_type": activityTypeVar };


		/* var component=this; */
		var jsonData = JSON.stringify(markers);
		var jsonOutput;

		fetch('http://192.168.104.63:8088/RESTCassandraTransactions_src/rest/Transaction/select/' + jsonData,
			{
				method: "POST"
			})
			.then(res => {
				
				return res.json();
			})
			.then(resSum => {
				var arrTen = [];
				for (var k = 0; k < resSum.length; k++) {
					arrTen.push(<option key={resSum[k].act_name} value={resSum[k].act_name}> {resSum[k].act_name} </option>);
				}
				component.setState({ items: arrTen });
			});
/* 		console.log(this.state.items)
 */	};
	deleteRow() {
		console.log("I am inside the deleteRow()"+this.state.list);
		var component = this;
		
		var activityTypeVar = this.state.list;
		this.deleteStatus='Ok'
		/* var items;1
		var finData; */
		/* if (this.props.num == 1) { activityTypeVar = "template1" };
		if (this.props.num == 2) { activityTypeVar = "Carrier Addition" };
		if (this.props.num == 3) { activityTypeVar = "Sector Addition" }; */
		 
		var markers = { "act_name": activityTypeVar };
		
	
		

		/* var component=this; */
		var jsonData = JSON.stringify(markers);
		var jsonOutput;

		fetch('http://192.168.104.63:8088/RESTCassandraTransactions_src/rest/Transaction/delete/' + jsonData,
			{
				method: "POST"
				
			})
			.then(res => {
				return res.json();
			})
			.then(resSum => {
				/* var arrTen = [];
				for (var k = 0; k < resSum.length; k++) {
					arrTen.push(<option key={resSum[k].act_name} value={resSum[k].act_name}> {resSum[k].act_name} </option>);
				} */
				
				component.setState({ items1: resSum.status });
				//console.log(activityTypeVar+" "+resSum.status);
				
			});
		

	}


	render() {

		
		
		/* var file = [];
		for (var i = 0; i < this.props.num; i++) {
			file.push(<input type	 = "file" name="file1"/> );
			file.push(<br/>)
		} */
		

		/* var uploadfile = [];
		if (this.props.num != 0) {
			uploadfile.push(<UpLoad />);
		} */

		if (this.props.num == 0) {
			return (
				<div>
					<br />
					<div className="left-center">
						<div className="container">

							<button id="newbutton" type="button" className="btn btn-primary" disabled > New</button>
							&nbsp;&nbsp;
							<button id="deletebutton" type="button" className="btn btn-primary" disabled > Delete </button>
						</div>
					</div>
					<div className="selectWrapper">
						<label>  <center>&nbsp;&nbsp; TemplateList </center> </label>
						<select id="list" name="list" size="13" className="selectBox" disabled>
						</select>
					</div>
				</div>
			);
		}
		if (this.props.num != this.numForVerification) {

			{ this.selectData() }
			this.numForVerification = this.props.num;
		}
		
		if(this.deleteStatus == this.state.items1){
			{this.selectData()}
			this.deleteStatus = "not ok";
			//this.state.list="";
		}
	
		if (this.props.num == 1) {
		return (
			<div>
				<br />
				

				<div className="left-center">
					<div className="container">

						<button id="newbutton" type="button" disabled={!this.state.list} className="btn btn-primary"  onClick={this.toggleModal} > New</button>
						&nbsp;&nbsp;
						<Modal show={this.state.isOpen} onClose={this.toggleModal} >
							
							<br />
							<br />
							{/* {file} */}

							<br />
							
							<UpLoad2 />
						</Modal>


						<button id="deletebutton" type="button" disabled={!this.state.list} className="btn btn-primary"  onClick={() => { this.deleteRow() }}> Delete </button>
						{/* this.selectData() */}			
					</div>
				</div>
				<div>

				</div>
				<br/>
				<div className="selectWrapper">


					<label> <center>&nbsp;&nbsp; TemplateList </center></label>
					<select id="list" name="list" size="13" className="selectBox" value={this.state.list} onChange={this.handleChange}>
					
					<option ></option>
						{this.state.items}
						{/* { Object.keys(this.state.items).map((k, index) => <li key={index}>{ `${this.state.items[k].act_name}` }</li>) } */}

						{/* <option value="RCom" > RCom </option>
				<option value="RCom" > RCom </option>
				<option value="Ariel" > Ariel </option>
				<option value="Calibri" > Calibri </option>
				<option value="Cambia" > Cambia </option>
						<option value="times" > times </option> */}
					</select>

				</div>

			</div>

		);
	}
	if (this.props.num == 2) {
		return (
			<div>
				<br />
				

				<div className="left-center">
					<div className="container">

						<button id="newbutton" type="button" disabled={!this.state.list} className="btn btn-primary"  onClick={this.toggleModal} > New</button>
						&nbsp;&nbsp;
						<Modal show={this.state.isOpen} onClose={this.toggleModal} >
							
							<br />
							<br />
							{/* {file} */}

							<br />
							
							<UpLoad1 />
						</Modal>


						<button id="deletebutton" type="button" disabled={!this.state.list} className="btn btn-primary"  onClick={() => { this.deleteRow() }}> Delete </button>
						{/* this.selectData() */}			
					</div>
				</div>
				<div>

				</div>
				<br/>
				<div className="selectWrapper">


					<label> <center>&nbsp;&nbsp; TemplateList </center></label>
					<select id="list" name="list" size="13" className="selectBox" value={this.state.list} onChange={this.handleChange}>
					
					<option ></option>
						{this.state.items}
						{/* { Object.keys(this.state.items).map((k, index) => <li key={index}>{ `${this.state.items[k].act_name}` }</li>) } */}

						{/* <option value="RCom" > RCom </option>
				<option value="RCom" > RCom </option>
				<option value="Ariel" > Ariel </option>
				<option value="Calibri" > Calibri </option>
				<option value="Cambia" > Cambia </option>
						<option value="times" > times </option> */}
					</select>

				</div>

			</div>

		);
	}
	if (this.props.num == 3) {
		return (
			<div>
				<br />
				

				<div className="left-center">
					<div className="container">

						<button id="newbutton" type="button" disabled={!this.state.list} className="btn btn-primary"  onClick={this.toggleModal} > New</button>
						&nbsp;&nbsp;
						<Modal show={this.state.isOpen} onClose={this.toggleModal} >
							
							<br />
							<br />
							{/* {file} */}

							<br />
							
							<UpLoad />
						</Modal>


						<button id="deletebutton" type="button" disabled={!this.state.list} className="btn btn-primary"  onClick={() => { this.deleteRow() }}> Delete </button>
						{/* this.selectData() */}			
					</div>
				</div>
				<div>

				</div>
				<br/>
				<div className="selectWrapper">


					<label> <center>&nbsp;&nbsp; TemplateList </center></label>
					<select id="list" name="list" size="13" className="selectBox" value={this.state.list} onChange={this.handleChange}>
					
					<option ></option>
						{this.state.items}
						{/* { Object.keys(this.state.items).map((k, index) => <li key={index}>{ `${this.state.items[k].act_name}` }</li>) } */}

						{/* <option value="RCom" > RCom </option>
				<option value="RCom" > RCom </option>
				<option value="Ariel" > Ariel </option>
				<option value="Calibri" > Calibri </option>
				<option value="Cambia" > Cambia </option>
						<option value="times" > times </option> */}
					</select>

				</div>

			</div>

		);
	}
			
		/* }   */

		/* if (this.props.num == 2) {
			return (
				<div>
					<br />

					<div className="left-center">
						<div className="container">
							<button id="newbutton" type="button" disabled={!this.state.list} className="btn btn-primary" onClick={this.toggleModal}  > New</button>
							&nbsp;&nbsp;
		<Modal show={this.state.isOpen} onClose={this.toggleModal} >
								Select your files
			<br />
								<br />

								{file}
								<UpLoad />
								<br />

							</Modal>


							<button id="deletebutton" type="button" disabled={!this.state.list} className="btn btn-primary" > Delete </button>
						</div>
					</div>
					<div className="selectWrapper">
						<label>  <center> &nbsp;&nbsp;TemplateList </center> </label>
						<select id="list" name="list" size="13" className="selectBox" value={this.state.list} onChange={this.handleChange}>

							<option value="RCom1" > RCom1 </option>
							<option value="Ariel1" > Ariel1 </option>
							<option value="Calibri1" > Calibri1 </option>
							<option value="Cambia1" > Cambia1 </option>
							<option value="times1" > times1 </option>
						</select>
					</div>

				</div>


			);
		}
		if (this.props.num == 3) {
			return (
				<div>
					<br />

					<div className="left-center">
						<div className="container">

							<button id="newbutton" type="button" disabled={!this.state.list} onClick={this.toggleModal} className="btn btn-primary"> New</button>
							&nbsp;&nbsp;
			<Modal show={this.state.isOpen} onClose={this.toggleModal} >
								Select your files
			<br />
								<br />
								{file}
								<UpLoad />
								<br />

							</Modal>
				
							<button id="deletebutton" type="button" disabled={!this.state.list} className="btn btn-primary"> Delete </button>
						</div>
					</div>
					<div className="selectWrapper">
						<label>  <center> &nbsp;&nbsp;TemplateList </center> </label>
						<select id="list" name="list" size="13" className="selectBox" value={this.state.list} onChange={this.handleChange}>

							<option value="RCom2" > RCom2 </option>
							<option value="Ariel2" > Ariel2 </option>
							<option value="Calibri2" > Calibri2 </option>
							<option value="Cambia2" > Cambia2 </option>
							<option value="times2" > times2 </option>
						</select>
					</div>

				</div>

			);
		} */


	}
}

export default TemplateList;
