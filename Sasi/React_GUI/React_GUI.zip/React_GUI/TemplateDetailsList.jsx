import React from 'react';

class TemplateDetailsList extends React.Component {
	
		constructor(props){
			super(props);
		}  
		
					

 render() {

 	if(this.props.list=='RCom'){
	 return (
			<div>
		<div className="selectWrapper">
	<select id = "list1" name="list1" className="selectBox" size="5">
				<option disabled> My List </option>
					
				<option value="RCom" > RCom </option>
				<option value="Ariel" > Ariel </option>
				<option value="Calibri" > Calibri </option>
				<option value="Cambia" > Cambia </option>
				<option value="times" > times </option>
			  </select>
			  
		
		</div>
	    </div>
			
				 );
	}
	if(this.props.list=='Ariel'){
	 return (
			<div>
		<div className="selectWrapper">
	<select id = "list1" name="list1" className="selectBox" size="5" >
				<option disabled> My List </option>
					
				<option value="RCom" > RCom </option>
				<option value="Ariel" > Ariel </option>
				<option value="Calibri" > Calibri </option>
				<option value="Cambia" > Cambia </option>
				<option value="times" > times </option>
			  </select>
			  
		
		</div>
	    </div>
			
				 );
	}
 if(this.props.list=='calibri'){ 
    return (
	  <div>
	  <div className="selectWrapper">
            <select id = "list" className="selectBox" name="list" size="5" onChange={this.handleChange}>
				<option disabled>  My List </option>
				<option value="RCom" > RCom </option>
				<option value="Ariel" > Ariel </option>
				<option value="Calibri" > Calibri </option>
				<option value="Cambia" > Cambia </option>
				<option value="times" > times </option>
			  </select>
		
			</div>
			
			</div>
			 );
}
if(this.props.list=='cambia'){
    return (
	  <div>
	  <div className="selectWrapper">
            <select id = "list" name="list" className="selectBox" size="5"  onChange={this.handleChange}>
				<option disabled> My List </option>
				<option value="RCom" > RCom </option>
				<option value="Ariel" > Ariel </option>
				<option value="Calibri" > Calibri </option>
				<option value="Cambia" > Cambia </option>
				<option value="times" > times </option>
					  </select>

		</div>
		</div>
	
			 );
}
		
	
   }
}

export default TemplateDetailsList;
