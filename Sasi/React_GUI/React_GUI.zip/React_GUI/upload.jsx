import React from 'react'
import axios, { post } from 'axios';

class upload extends React.Component {

  constructor(props) {
    super(props);
    this.state ={
      file:[]
    }
    this.onFormSubmit = this.onFormSubmit.bind(this)
    this.onChange = this.onChange.bind(this)
    this.fileUpload = this.fileUpload.bind(this)
  }
  onFormSubmit(e){
    e.preventDefault() // Stop form submit
    this.fileUpload(this.state.file)
    console.log(this.state.file)
  }
  onChange(e) {
    this.state.file.push(e.target.files[0]);
  }
  fileUpload(file){
    const url = 'http://example.com/file-upload';
    const formData = new FormData();
    for(var i=0;i<file.length;i++)
    {
      formData.append("file"+i,file[i] );
    }
    
    console.log(formData);
    fetch("http://localhost:6002/FileUploaderFromReact/getFileFromReact", {
      mode: 'no-cors',
      method: "POST",
      body: formData
    })
  
  }

  render() {
    return (
      <form onSubmit={this.onFormSubmit}>
        <select id="list" name="list"  >
						<option value="1" > data </option>
						<option value="2" > Schema </option>
						<option value="3" > output </option>
				  </select> <br/><br/><br/><br/><br/>
        <input type="file" onChange={this.onChange} /><br/><br/>
        <input type="file" onChange={this.onChange} /><br/><br/>
        <input type="file" onChange={this.onChange} /><br/><br/>
        <button type="submit">Upload</button>
      </form>
   );
  }
}



export default upload;