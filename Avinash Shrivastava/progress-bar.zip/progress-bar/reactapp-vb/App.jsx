
import RestApp from './RestApp.jsx';
import React, { Component } from 'react';
//import Request from 'react-http-request';
import file from './config.js';
import fetch from 'isomorphic-fetch';
import Promise from 'promise';
class App extends Component {
	 constructor(props) {
    super(props);
    this.state = {
    
     
		isToggleOn: true
	
	};

this.frame=this.frame.bind(this);
    this.move = this.move.bind(this);
    this.render=this.render.bind(this);
  }
componentDidMount(){
  // console.log("calling setInterval");
  //    var id = setInterval(this.move, 1000);
  // // this.setState({id:id});
  //    fetch(file.data + "/getnum/")
	// 	.then(result=>result.json())
  //   .then(prog=>this.setState({num:prog}));
    //setInterval(this.render,5000);
}

 frame() {
   
    
// console.log("num : "+this.state.num);
    

// var elem = document.getElementById("myBar");
//     if (this.state.num > 100) {
// //clearInterval(this.state.id);
//     } else {

//       //this.setState({num:this.state.num+10}) ;
//       elem.style.width = this.state.num + '%'; 
      
// 	 if(this.state.num==100){
// 		 var e1=document.getElementById("val");
// 	e1.style.display="block";
//   }
  
// }
// //ReactDom.mountComponentAtNode(document.getElementById('app'));
  }
  move() {
 
  // var elem = document.getElementById("myBar");   
  // console.log(elem);
  // var width = 1;

  
  }
render() {

		var bb=Math.random();
    

return (

 <div>
 <h1>Avinash</h1>

<div><RestApp/></div>
</div>
);
}
}
export default App;