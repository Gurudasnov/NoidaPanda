var restURL =  "http://localhost:8080/NPO-restCall/rest/json/data";
module.exports = {data: restURL};

