import React, { Component } from 'react';
import Request from 'react-http-request';
import file from './config.js';
import fetch from 'isomorphic-fetch';
import Promise from 'promise';

 class RestApp extends React.Component {
	constructor(props) {
  	super(props);
 		 this.state={
			 items:[],
			 num:null,
			 id:0
		 };
		 this.frame=this.frame.bind(this);
		 this.refreshPage=this.refreshPage.bind(this);
  }
  componentDidMount(){

	 
	var id=setInterval(this.refreshPage,5000);
	this.setState({id:id});
  }
refreshPage(){

var myInit = {
  method: 'GET',
  headers: myHeaders,
};

	 fetch(file.data + "/getnum/",myInit)
		.then(result=>result.json())
    .then(prog=>this.setState({num:prog}));
		var elem = document.getElementById("myBar");
    if (this.state.num > 100) {
clearInterval(this.state.id);
    } else {

      //this.setState({num:this.state.num+10}) ;
      elem.style.width = this.state.num + '%'; 
      
	 if(this.state.num==100){
		 var e1=document.getElementById("val");
	e1.style.display="block";
  }
  
}
}
	frame() {
  
//this.forceUpdate();
	}
  render() {
    
	
	  return(
	 
	 

	 
<div className="w3-container">
 

  <div className="w3-light-grey">
    <div id="myBar" className="w3-orange myclass">{this.state.num}%</div>
  </div>
 
   <br>
   </br>
  <button className="w3-button w3-blue" onClick={this.frame}>Show-progress</button> 
  <div id="avi"></div>
    <div className="w3-light-yellow">
    <div id="val" className="av"></div>
  </div>
  
</div>
 


   );
   
  }
}

export default RestApp;