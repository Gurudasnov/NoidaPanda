import React from 'react';
import ReactDOM from 'react-dom';
import App from './App.jsx';
import RestApp from './RestApp.jsx';

ReactDOM.render(<App />, document.getElementById('app'));
//ReactDOM.render(<RestApp />, document.getElementById('RestApp1'));