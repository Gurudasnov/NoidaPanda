All React-js components should go in here
