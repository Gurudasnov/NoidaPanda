import React,{Component} from 'react';

class Execute extends Component {
   render() {
      return (
         <div>
            <h1>Hello.... Execute!</h1>
         </div>
      )
   }
}

export default Execute;