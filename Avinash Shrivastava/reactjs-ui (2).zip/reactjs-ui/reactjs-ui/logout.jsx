import React,{Component} from 'react';

class logout extends Component {
   render() {
      return (
         <div>
            <h1>Hello.... Logout!</h1>
         </div>
      )
   }
}

export default logout;