All HTML & view related files go in here.
