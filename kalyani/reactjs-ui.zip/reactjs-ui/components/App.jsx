import React from 'react';
import ReactDOM from 'react-dom';
import {Link} from 'react-router-dom';
import {Switch,Route} from 'react-router-dom';
import Admin from './admin.jsx';
import Workflow from './workflow.jsx';
import Execute from './execute.jsx';
import User1 from './user1.jsx';
import Logout from './logout.jsx';
import DB from './DB.jsx';
import AppsDropDown from './AppsDropDown.jsx';
class App extends React.Component {
   render() {
      return (
		 
			
        <div class="container" >
			<h3 className='col'>NPO work bench</h3>
			<link rel='stylesheet' type='text/css' href='../css/style.css'/>
            <ul className='unordered-list'>
				<li className='list'><Link to='/admin'> Admin  </Link></li>
				<li className='list'><Link to='/appsDropDown'> Apps  </Link></li>
				<li className='list'><Link to='/workflow'> Workflow  </Link></li>
				<li className='list'><Link to='/execute'> Execute  </Link></li>
				{/* <li className='list'><Link to='/DB'> Data Builder  </Link></li> */}
				<li className='menu'><Link to='/user1'> User1  </Link></li>
				<li className='menu'><a href="#">Logout</a></li>
            </ul>
			<Switch>
				<Route path='/admin' component={Admin}/>
				<Route path='/workflow' component={Workflow}/>
				<Route path='/Execute' component={Execute}/>
				<Route path='/user1' component={User1}/>
				<Route path='/appsDropDown' component={AppsDropDown}/>
				<Route path='/DB' component={DB}/>
			</Switch>
        </div>
      );
   }
}

export default App;