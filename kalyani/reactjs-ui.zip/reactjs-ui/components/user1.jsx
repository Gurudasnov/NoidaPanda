import React,{Component} from 'react';

class user1 extends Component {
   render() {
      return (
         <div>
            <h1>Hello.... User1!</h1>
         </div>
      )
   }
}

export default user1;