import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component 
{
  constructor(props)
  {
    super(props);
    this.state = {
		value: '',
		value1: '',
		role:''
	 };

  }

  handleChange(event)
  {
    this.setState({value:event.target.value});
	
	
  }
  
  handleChange1(event)
  {
	  
   	this.setState({value1: event.target.value});
  }

  handleSubmit(event)
  {
	  event.preventDefault();
	  
	 	if(this.state.value=="admin"){
	var ele=document.getElementById("ad");
	var ele1=document.getElementById("ab");
	ele1.style.display="none";
	ele.style.display="block";
		}
		else if(this.state.value=="operator"){
			var ele=document.getElementById("oli");
				var ele1=document.getElementById("ab");
	ele1.style.display="none";
			ele.style.display="block";
		
  }
  else if(this.state.value=="lead"){
  var ele=document.getElementById("lli");
  	var ele1=document.getElementById("ab");
	ele1.style.display="none";
			ele.style.display="block";
  }
  else{
  alert('error' + this.state.value); 
  }
  }
 
  render() 
  {
	  
	 
    return (
	
<div>
	<div id="ab" className="a2">
      <form onSubmit={this.handleSubmit.bind(this)}>
	  
        <label>
          Username: 
          <input id='user' type="text" value={this.state.value} onChange={this.handleChange.bind(this)} />
        </label>
        <br/>

         <label>
          Password:      
          <input type="password" value={this.state.value1} onChange={this.handleChange1.bind(this)} />
        </label>
        <br/>
      <br/>
  <input type="submit" value="Submit"/>
	<input type="submit" value="Cancel"/>
		</form>
	  
	  </div>
	  <div id="ad" className="a1"><AdminLogin/></div>
	  <h1 id="oli" className="a1"><OpertLogin/></h1>
	  <h1 id="lli" className="a1"><LeadLogin/></h1>
</div>
    );
	  
		
	  }
  }



class AdminLogin extends React.Component 
{
	
	render(){
   
	  
      return (
         <div>
            <h1>
			AdminLogin
			</h1>
         </div>
      );
	  
	}
}


class OpertLogin extends React.Component 
{
   render() {
      return (
         <div>
            <h1>OperatorLogin</h1>
         </div>
      );
   }
}


class LeadLogin extends React.Component 
{
   render() {
      return (
         <div>
            <h1>LeadLogin</h1>
         </div>
      );
   }
}


export default App;

