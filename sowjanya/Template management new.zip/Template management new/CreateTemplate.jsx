import React from 'react';
import TableList from './TableList.jsx';

class CreateTemplate extends React.Component {
	   render() {
      return (
		<div>
		
		<h3><center> Create Template </center></h3>
			<div className="form-group">
				<b> Template Name:</b>&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" placeholder="enter here"/>
				<br/>
			</div>			
			<br/>			
				<div className="right-Modal">
				<table className="gridview">
				<thead>
				<tr >
				<th>&nbsp;&nbsp;Table List</th>
				<th>&nbsp;&nbsp;Column List</th>
				</tr>
				</thead>
				<tbody>
				<tr><td>Table1</td><td>column1</td>
				</tr>
				<tr><td>Table2</td><td>column2</td>
				</tr>
				<tr ><td>Table3</td><td>column3</td>
				</tr>
				<tr ><td>Table4</td><td>column4</td>
				</tr>
				<tr ><td>Table5</td><td>column5</td>
				</tr> 
				</tbody>
				</table>
			</div>
				
			
		   <div className="left-center-Modal">
		
			<button type="button" className="btn btn-primary" data-toggle="tooltip" title="Add">
			<span className="glyphicon glyphicon-chevron-right"></span> &nbsp;&nbsp;&nbsp; Add &nbsp;&nbsp;&nbsp;
			</button>
			<br/>
			<br/>		
			<button type="button" className="btn btn-primary" data-toggle="tooltip" title="Remove">
			<span className="glyphicon glyphicon-chevron-left"></span> &nbsp;Remove&nbsp;
			</button>
			</div>
			
			<div className="box-Modal">Select a list and click on add</div><br/>
			<div className="selectWrapper">

			<select id = "Tablelist" name="Tablelist" size="8" className="selectBox-Modal" >    
				<option value="Table List" selected="true" disabled="disabled"  >&nbsp; Table List </option>
			
				<option value="table1">&nbsp; table1 </option>
				<option value="table2">&nbsp; table2</option>
				<option value="table3">&nbsp; table3</option>
				<option value="table4">&nbsp; table4</option>
			</select>

			</div>	
			<br/>
			
			<div className="selectWrapper">
			
			<select multiple data-toggle="tooltip" title="Hold shift or ctrl to select multiple" id = "columnlist" name="columnlist" size="8" className="selectBox-Modal" >        
				<option value="column List" selected="true" disabled="disabled"  >&nbsp; Column List </option>
				<option value="column1">&nbsp; column1</option>
				<option value="column2">&nbsp; column2</option>
				<option value="column3">&nbsp; column3</option>
				<option value="column4">&nbsp; column4</option>
			</select>
			</div>			
		</div>
		
		
		
      );
   }
}
export default CreateTemplate;
