import React from 'react';
import TemplateManagement from './TemplateManagement.jsx';
import TemplateList from './TemplateList.jsx';


class App extends React.Component {
   render() {
      return (
         <div className="container-fluid">
           <link rel='stylesheet' type='text/css' href='style.css'/>
		   
           <br/>
			<br/>
			<br/>
			<br/>
			<br/>
			<br/>
			<br/>
			<br/>
			{/* <div className="left">
			<TemplateList />
   </div> */}
			<TemplateManagement />
			
		
         </div>
      );
   }
}

export default App;
