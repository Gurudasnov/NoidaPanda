import React from 'react';
import ReactDOM from 'react-dom';
/* import $ from 'jquery'; */
class TableList extends React.Component {
		constructor(props){
		super(props);	
		this.state = {
			data: [
				{id:1, name: 'Hello'},
				{id:2, name: 'World'},
				{id:3, name: 'How'},
				{id:4, name: 'Are'},
				{id:5, name: 'You'},
				{id:6, name: '?'}
			],
			 myTable : [
				{
					id:1,
					TableList:"Table 1",
					ColoumnList:["Column1",
					"Column2",
					"Column3",
					"Column4","Column5"]
	
					
				},
				{
					id:2,
					TableList:"Table 2",
					ColoumnList:["Column1",
					"Column2",
					"Column3",
					"Column4","Column5"]
					
				},
				{
					id:3,
					TableList:"Table 3",
					ColoumnList:["Column1",
					"Column2",
					"Column3",
					"Column4","Column5"]
				},
				{
					id:4,
					TableList:"Table 4",
					ColoumnList:["Column1",
					"Column2",
					"Column3",
					"Column4","Column5"]
					
				},
				{
					id:5,
					TableList:"Table 5",
					ColoumnList:["Column1",
					"Column2",
					"Column3",
					"Column4",
					"Column5"]
					
				}
			
			] 
		
	
		  }
		}

		myFunction(event) {
			console.log(this+"i")
			document.getElementById("myTableList").deleteRow(this);
	
		}
		/* deleteR(row){
			const newRow = this.state.myTable;
			if(newRow.indexOf(row) > -1){
				newRow.splice(newRow.indexOf(row),1);
				this.setState({myTable: newRow})
			}
		} */
		
		
		  
  delete(item){
    const newState = this.state.data;
  	if (newState.indexOf(item) > -1) {
    	newState.splice(newState.indexOf(item), 1);
      this.setState({data: newState})
    }
  }

		render() {  
		  
			
		
		 var myTable = [
			{
				id:1,
				TableList:"Table 1",
				ColoumnList:["Column1",
				"Column2",
				"Column3",
				"Column4","Column5"]

				
			},
			{
				id:2,
				TableList:"Table 2",
				ColoumnList:["Column1",
				"Column2",
				"Column3",
				"Column4","Column5"]
				
			},
			{
				id:3,
				TableList:"Table 3",
				ColoumnList:["Column1",
				"Column2",
				"Column3",
				"Column4","Column5"]
			},
			{
				id:4,
				TableList:"Table 4",
				ColoumnList:["Column1",
				"Column2",
				"Column3",
				"Column4","Column5"]
				
			},
			{
				id:5,
				TableList:"Table 5",
				ColoumnList:["Column1",
				"Column2",
				"Column3",
				"Column4",
				"Column5"]
				
			}
		
		]
		/* const listItem = this.state.data.map((item)=>{
			return <div key={item.id}>
			  <span>{item.name}</span> <button onClick={this.delete.bind(this, item)}>Delete</button>
		  </div>
		}) */
		var col = [];
		var i;
		for(i = 0; i <this.state.myTable.length; i++) {
			col.push(
			<tr key={i-2}><td>{this.state.myTable[i].id}</td><td>{this.state.myTable[i].TableList} </td><td> 
			{this.state.myTable[i].ColoumnList[i]}</td>
			<td>
			<button id = "deletebutton" type="button" className="btn btn-primary" value={i-4}  
			onClick={this.myFunction.bind(this.state.myTable[i].id)}>delete</button> </td> </tr> );
			
			}

				/*  var myTableData = myTable.map((myTable)=>
					
				{for(i = 0; i < myTable.length; i++) {
					col.push(
					<tr key={myTable[i].id}><td>{myTable[i].id}</td><td>{myTable[i].TableList} </td><td> 
					{myTable[i].ColoumnList[i]}</td>
					<td>
					<button id = "deletebutton" type="button" className="btn btn-primary" value={myTable[i].id}  
					onClick={this.myFunction.bind(this)}>delete</button> </td> </tr> );
					console.log("i="+i);
					}
					<div key={myTable.id}>
					return {col}
					</div> 
				
				}) */

			 var myTableData = myTable.map((myTable)=>
				{
/* 						for(i = 0; i <row.length; i++) {
						col.push(<tr key={row.id}> <td>{ i+1 }</td><td>{row[i].TableList} </td><td> 
						{row[i].ColoumnList[i]}</td>
						<td>
						<button id = "deletebutton" type="button" className="btn btn-primary" value={i}  
						onClick={this.deleteR.bind(this,row)}>delete</button> </td> </tr> );
						console.log("i="+i);
						} */
						<div key={myTable.id}>
						return {col}
						</div> 
				
				}) 
				 
		return (
		<div>
			<div className="right">
			   
	    	<table className="gridview">
	   		<thead>
			<tr>
			<th>&nbsp;&nbsp;S.No </th>
			<th>&nbsp;&nbsp;Table List</th>
			<th>&nbsp;&nbsp;Column List</th>
			<th>&nbsp;&nbsp;&nbsp;Action</th>
			</tr>
			</thead>
			<tbody id="myTableList">
		{col}
{/* 	{myTableData}   */}
			</tbody>
			</table>
		{/* 	{listItem} */}

		</div>
	</div>
		 );
   }
}

export default TableList;
