import React from 'react';
import TableList from './TableList.jsx';

class TemplateList extends React.Component {
	   render() {
      return (
		<div>


		<div className="selectWrapper">
			
			<label> <center> &nbsp;&nbsp;TemplateList </center></label>
			
            <select id = "templatelist" name="list" size="11" className="selectBox" >
									
				<option value="RCom" > RCom </option>
				<option value="Ariel" > Ariel </option>
				<option value="Calibri" > Calibri </option>
				<option value="Cambia" > Cambia </option>
				<option value="times" > times </option>
			  </select>
			
			</div>
		</div>
      );
   }
}
export default TemplateList;
