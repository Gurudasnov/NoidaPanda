import React from 'react';
import TableList from './TableList.jsx';
import TemplateList from './TemplateList.jsx';
import PropTypes from 'prop-types';
import Modal from './Modal.jsx';
import CreateTemplate from './CreateTemplate.jsx';
class TemplateManagement extends React.Component {
	constructor(props){
		super(props);
		this.state = {isOpen:false};
			
		this.toggleModal = this.toggleModal.bind(this);
		
		}
		 
		
		
		toggleModal() {
			this.setState({	isOpen:!this.state.isOpen});
		}
	   render() {
      return (
		<div>
		<div className="right">
			<TableList />
		</div>		
		<div className="left-center">
		<br/>
		<br/>
			<button id = "createbutton" type="button" className="btn btn-primary" onClick={this.toggleModal}> Create</button> 
			<br/>
			<br/>
			
			{/* <button id = "deletebutton" type="button" className="btn btn-primary" > Delete </button> */}
		</div>	
				
				
		<div className="left">
			<TemplateList />
		</div>
	   	
		
		<Modal show={this.state.isOpen} onClose={this.toggleModal} >
			<CreateTemplate />
		</Modal>
				
		
		
		</div>
		
		
		
      );
   }
}
export default TemplateManagement;
