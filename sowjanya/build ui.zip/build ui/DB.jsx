import React from 'react';
import FileDB from './filedb.jsx';
import FileChooser from './filechooser.jsx';
import UpLoad from './upload.jsx';
import TemplateList from './TemplateList.jsx';

class DB extends React.Component
{
	constructor(){
		super();
		this.state={
		num:1
    };
	}
	updateNum(event){
			this.setState({num:event.target.value});
			}	
	render(){
	var file=[];
		for(var i=0;i<this.state.num;i++){
		file.push(<FileChooser key={i} />);
		}
	return(
	<div>
			<div className = "center" >
			
			 <h4> select an option to upload files </h4>
			<select value="select" onChange={this.updateNum.bind(this)}>
				<option value="0" >select</option>
				<option value="1" >Site Creation</option>
				<option value="2" >Carrier Addition</option>
				<option value="3" >Sector Addition</option>
			</select>
		
			<br/>
			<br/>
			<br/>
			<br/>
			<br/>
									
				<input type ="button" value ="Edit"/> 
					<br/>
					<br/>
				<input type ="button" value ="Delete"/>
			</div>	
				 <div id="appear" className="left">
						<TemplateList num={this.state.num}/>
					</div>
				
				<div className = "spacing">
				<div className = "fieldset">
					<h1><span>New/Edit</span></h1> 

					<br/>
					<br/>
					
			
						{file} 
			
					<br/>
						<UpLoad /> 
					
				</div>
				</div>	
					
	</div>
	);
	}
	
}

export default DB;
