import React from 'react';

class TemplateList extends React.Component {
constructor(props){
super(props);

}
   render() {

if(this.props.num==1){
 return (
	  <div>
          <ul className ="list-unstyled">
			<li> <h4> TemplateList </h4> </li>
      
            <li>Roboto</li>
            <li>Ariel</li>
            
		<li>Calibri</li>
            <li>cambria</li>
        </ul>
</div>
			 );
}
 if(this.props.num==2){ 
    return (
	  <div>
          <ul className ="list-unstyled">
			<li> <h4> TemplateList </h4> </li>
      
            <li>Times</li>
            <li>Italic</li>
            
		<li>Bold</li>
            <li>NPO</li>
        </ul>
</div>
			 );
}
if(this.props.num==3){
    return (
	  <div>
          <ul className ="list-unstyled">
			<li> <h4> TemplateList </h4> </li>
      
            <li>Roboto3</li>
            <li>Ariel3</li>
            
		<li>Calibri3</li>
            <li>cambria3</li>
        </ul>
</div>
			 );
}
}
   }


export default TemplateList;
