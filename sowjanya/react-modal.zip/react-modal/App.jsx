import React, { Component } from 'react';
import DialogExampleModal from './DialogExampleModal.jsx';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';


class App extends Component {
  
  render() {
    return (
      <div>
	  
		<DialogExampleModal />
      </div>
    );
  }
}

export default App;
