import React, { Component } from 'react';

class TemplateDetailsList extends Component {
	
		constructor(props){
		super(props);
		this.state = {list:''};
			/* this.state = {list:''}; */
		} 
		
		handleChange(event) {
		this.setState({list:event.target.value});
		}
		


 render() {

 	if(this.props.num==0){
	 return (
			<div>
			
	<select id = "list" name="list" className="selectBox" size="5">
				<option disabled> Template Details List </option>
				
			  </select>
			  
	
	    </div>
			
				 );
	}
	if(this.props.num==1){
	 return (
			<div>
			
	<select id = "list" name="list" className="selectBox" size="5" value={this.state.list} onChange={this.handleChange}>
				<option disabled> Template List </option>
					
				<option value="RCom" > RCom </option>
				<option value="Ariel" > Ariel </option>
				<option value="Calibri" > Calibri </option>
				<option value="Cambia" > Cambia </option>
				<option value="times" > times </option>
			  </select>
			  
				
	    </div>
			
				 );
	}
 if(this.props.num==2){ 
    return (
	  <div>
            <select id = "list" className="selectBox" name="list" size="5" value={this.state.list} onChange={this.handleChange}>
				<option disabled> TemplateList </option>
				<option value="RCom1" > RCom1 </option>
				<option value="Ariel1" > Ariel1 </option>
				<option value="Calibri1" > Calibri1 </option>
				<option value="Cambia1" > Cambia1 </option>
				<option value="times1" > times1 </option>
			  </select>
			
</div>
			 );
}
if(this.props.num==3){
    return (
	  <div>
            <select id = "list" name="list" className="selectBox" size="5"  value={this.state.list} onChange={this.handleChange}>
				<option disabled> TemplateList </option>
				<option value="RCom2" > RCom2 </option>
				<option value="Ariel2" > Ariel2 </option>
				<option value="Calibri2" > Calibri2 </option>
				<option value="Cambia2" > Cambia2 </option>
				<option value="times2" > times2 </option>
			  </select>
	
			
		</div>
	
			 );
}
		
	
   }
}

export default TemplateDetailsList;
