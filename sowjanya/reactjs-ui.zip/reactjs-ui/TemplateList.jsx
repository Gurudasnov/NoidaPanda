import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Modal from './Modal.jsx';
import FileChooser from './filechooser.jsx';
import UpLoad from './upload.jsx';

class TemplateList extends Component {
	
		constructor(props){
		super(props);
		this.state = {isOpen:false, list:''};
			/* this.state = {list:''}; */
		this.toggleModal = this.toggleModal.bind(this);
		this.handleChange = this.handleChange.bind(this);


		{/* this.state = {
			list:''			
			};
		*/	}
		} 
		
  
		handleChange(event) {
		this.setState({list:event.target.value});
		}
		
		toggleModal() {
			this.setState({	isOpen:!this.state.isOpen});
		}
		
		/* toggleModal() {
		this.setState(prevState =>({
		  isOpen: !prevState.isOpen
		}));
		} */
		
		/* onIndexChanged (indexChanged) {
		this.setState({index: indexChanged})
		} */

 render() {
	 var file=[];
		for(var i=0;i<this.props.num;i++){
			file.push(<FileChooser key={i} />);
			}
			
		var uploadfile=[];
		if(this.props.num != 0)
		{
		uploadfile.push(<UpLoad />); 
		}

 	if(this.props.num==0){
	 return (
			<div>
			<br/>
				
			<div className="left-center">
			<div className="container">

		<button id = "newbutton" type="button" className="btn btn-primary" disabled > New</button> 
		&nbsp;&nbsp;
		<button id = "deletebutton" type="button" className="btn btn-primary" disabled > Delete </button>
		</div>
		
		</div>
		<div className="selectWrapper">
		<label>  <center>&nbsp;&nbsp; TemplateList </center> </label>
		  <select id = "list" name="list" size="13"  className="selectBox" disabled>
				
		</select>
		</div>
		
	    </div>
			
				 );
	}
	if(this.props.num==1){
	 return (
			<div>
			<br/>
		
			<div className="left-center">
			<div className="container">	
			
		<button id = "newbutton" type="button" disabled={!this.state.list} className="btn btn-primary"  onClick={this.toggleModal} > New</button>
		&nbsp;&nbsp;
		<Modal show={this.state.isOpen} onClose={this.toggleModal} >
			Select your files
			<br/>
			<br/>
			{file}
				
			<br/>
			<UpLoad />
		</Modal>
		 
		 
		<button id = "deletebutton" type="button" disabled={!this.state.list} className="btn btn-primary" > Delete </button>
		</div>
	    </div>
	  
			<div className="selectWrapper">
			
			<label> <center>&nbsp;&nbsp; TemplateList </center></label>
            <select id = "list" name="list" size="13" className="selectBox" value={this.state.list} onChange={this.handleChange}>
				
					
				<option value="RCom" > RCom </option>
				<option value="Ariel" > Ariel </option>
				<option value="Calibri" > Calibri </option>
				<option value="Cambia" > Cambia </option>
				<option value="times" > times </option>
			  </select>
			</div>
		
	    </div>
			
				 );
	}
 if(this.props.num==2){ 
    return (
	  <div>
	  <br/>
	  
	  <div className="left-center">
	  <div className="container">	
		<button id = "newbutton" type="button" disabled={!this.state.list} className="btn btn-primary" onClick={this.toggleModal}  > New</button>
		&nbsp;&nbsp;
		<Modal show={this.state.isOpen} onClose={this.toggleModal} >
		Select your files
			<br/>
			<br/>
			
			{file}
		<UpLoad />
			<br/>
			
			</Modal>
		 
		 
		<button id = "deletebutton" type="button" disabled={!this.state.list} className="btn btn-primary" > Delete </button>
		</div>
		</div>
		<div className="selectWrapper">
			<label>  <center> TemplateList </center> </label>
            <select id = "list" name="list" size="13" className="selectBox" value={this.state.list} onChange={this.handleChange}>
				
				<option value="RCom1" > RCom1 </option>
				<option value="Ariel1" > Ariel1 </option>
				<option value="Calibri1" > Calibri1 </option>
				<option value="Cambia1" > Cambia1 </option>
				<option value="times1" > times1 </option>
			  </select>
		</div>
		
		</div>
			

			 );
}
if(this.props.num==3){
    return (
	  <div>
	  <br/>
	  
	  <div className="left-center">
	  <div className="container">	
		
		<button id = "newbutton" type="button" disabled={!this.state.list}  onClick={this.toggleModal} className="btn btn-primary"> New</button>
		&nbsp;&nbsp;
			<Modal show={this.state.isOpen} onClose={this.toggleModal} >
		Select your files
			<br/>
			<br/>
			{file}
			<UpLoad />	
			<br/>
			
			</Modal>	
		{/* <button id = "editbutton"  type="button" disabled={!this.state.list} > Edit</button>
		<br/>
		<br/> */}
		<button id = "deletebutton" type="button" disabled={!this.state.list} className="btn btn-primary"> Delete </button>
		</div>
		</div>
		<div className="selectWrapper">
				<label>  <center> TemplateList </center> </label>
            <select id = "list" name="list" size="13" className="selectBox" value={this.state.list} onChange={this.handleChange}>
				
				<option value="RCom2" > RCom2 </option>
				<option value="Ariel2" > Ariel2 </option>
				<option value="Calibri2" > Calibri2 </option>
				<option value="Cambia2" > Cambia2 </option>
				<option value="times2" > times2 </option>
			  </select>
		</div>
		
		</div>
				
			 );
}
		
	
   }
}

export default TemplateList;
