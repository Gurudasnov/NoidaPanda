import React from 'react';
import FileChooser from './filechooser.jsx';
import UpLoad from './upload.jsx';

//import TemplateDetailsList from './TemplateDetailsList.jsx';

class Selection extends React.Component
{
	constructor(props){
		super(props);
		this.state={
			num:0
		};
	}
	
	updateNum(event){
		{/*this.setState({num:event.target.value});*/}
		this.props.callbackParent(event.target.value);
	}	
		
	
	render(){
	
			var file=[];
			for(var i=0;i<this.state.num;i++){
				file.push(<FileChooser key={i} />);
				}
				
								
			var uploadfile=[];
			if(this.state.num != 0)
			{
			uploadfile.push(<UpLoad />); 
			}
		
		
		return(
	
		<div> 
				<label> <h4> Select Activity &nbsp;&nbsp;</h4></label>
				  <div className="selectWrapper">
					<select id="list" name="list"   onChange={this.updateNum.bind(this)}>
						<option value="0" > select </option>
						<option value="1" > Site Creation </option>
						<option value="2" > Carrier Addition </option>
						<option value="3" > Sector Addition </option>
					</select> 
						
				</div>
						
						<br/>
						<br/>						
					{/*<TemplateDetailsList list={this.state.num}/>*/}
						{file} 
			        
					<br/>
									
						{uploadfile}	
				
				
						
		</div>
		);
	}
	
}


export default Selection;
