import React from 'react';
import Request from 'react-http-request';
import Fetch from "isomorphic-fetch";
var Promise = require('es6-promise').Promise;
Promise.polyfill();
var apiBaseUrl = "http://192.168.104.63:9990/RESTToListFilesOnEdit/rest/edit/getlist";
var request = require('superagent');

class Edit extends React.Component {

  constructor(props) {
    super(props);
    this.state = { files: [] };
  }
  componentDidMount()
 {
   this.clickEdit();
 }
 
  clickEdit(event){
		
						
		  fetch("http://192.168.104.63:9990/RESTToListFilesOnEdit/rest/edit/getlist", {
		  mode: 'no-cors',
		  method: "POST",
		  body: formData
		}).then(function (res) {
			if (res.ok) {
				alert("File Uploaded Successfully! ");
			} 	else if (res.status == 401) {
				alert("Oops! ");
				}
		}, 		function (e) {
				alert("Error submitting edit!");
				});
		}
  
	render() {
			return (
			
				<div >

				   		<button id = "editbutton" type="button" disabled={this.props.num} > Edit</button>

			 
				</div>
			);
		}
}
 
 export default Edit;