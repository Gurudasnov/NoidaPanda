import React from 'react';
import Request from 'react-http-request';
import Fetch from "isomorphic-fetch";
import Dropzone from 'react-dropzone';


var Promise = require('es6-promise').Promise;

// var Promise = require("es6-promise")
 Promise.polyfill();
// var axios = require("axios");

var apiBaseUrl = "http://192.168.104.63:8088/FileUploaderFromReact_servlet/getFileFromReact";
var request = require('superagent');

class UpLoad extends React.Component {

  constructor(props) {
    super(props);
    this.state = { files: [] };
  }
  
 componentDidMount()
 {
   this.handleClick();
 }

 
handleClick(event){
			console.log("handleClick",event);
			var self = this;
			var formData = new FormData();
			if(this.state.files.length>0){
				var filesArray = this.state.files;
					for(var i in filesArray){
						console.log(filesArray[i]);
						formData.append(this.state.files+i, filesArray[i]);
		}
			fetch("http://192.168.104.63:8088/FileUploaderFromReact_servlet/getFileFromReact", {
		  mode: 'no-cors',
		  method: "POST",
		  body: formData
		}).then(function (res) {
			if (res.ok) {
				alert("File Uploaded Successfully! ");
			} 	else if (res.status == 401) {
				alert("Oops! ");
				}
		}, 		function (e) {
				alert("Error submitting form!");
				});
		}
}


render(){
		return (
		
			<div >

               <button id = "uploadbutton" type="button" onClick={(event)=>this.handleClick(event)} className="btn btn-primary"> Upload</button>
         
			</div>
		);
	}
}


export default UpLoad;