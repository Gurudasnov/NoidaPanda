import React from 'react';
import Admin from './admin.jsx';
import ReactDOM from 'react-dom';
import {Link} from 'react-router-dom';
import {Switch,Route} from 'react-router-dom';
import DB from './DB.jsx';

class AppsDropDown extends React.Component {
   render() {
      return (
         <div className="addm">
		 <link rel='stylesheet' type='text/css' href='../css/style.css'/>
		 <ul className="rmDots">
		 <li >Templates</li>
		 <li >Logic Management</li>
		 <li ><Link to='/DB'> Data Builder  </Link></li>
		 
		 
		 <li >Tracker</li>
		 
		 </ul>
		 <Switch>
			 
		 	 <Route path='/DB' component={DB}/>
			
		 </Switch>
         </div>
      );
   }
}

export default AppsDropDown;