import React from 'react';
import FileDB from './filedb.jsx';
import FileChooser from './filechooser.jsx';

class DB extends React.Component
{
	constructor(){
	super();
    this.state={
	num:''
    };
	}
updateNum(event){
this.setState({num:event.target.value});
}
	render(){
	var file=[];
		for(var i=0;i<this.state.num;i++){
		file.push(<FileChooser key={i} />);
		}
	return(
	<div>
	<h1> select an option to upload files </h1>
		<select value="select" onChange={this.updateNum.bind(this)}>
			<option value="0" >select</option>
			<option value="1" >A</option>
			<option value="2" >B</option>
			<option value="3" >C</option>
		</select>
		
		<br/>
		<br/>
			
	{file}
		<br/>
		<button type="button" class="btn btn-success">Submit</button>
		
	</div>
	);
	}
	
}

export default DB;
