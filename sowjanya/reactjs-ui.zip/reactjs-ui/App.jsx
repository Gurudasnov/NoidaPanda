import React from 'react';
import DB from './DB.jsx';

class App extends React.Component {

   render() {
      return (
		
         <div className="container" >
           <link rel='stylesheet' type='text/css' href='style.css'/>
		   
            <ul className='unordered-list'>
              <li className='list'><a className='list-link' href="#home">Home</a></li>
              <li className='list'><a className='list-link' href="#news">News</a></li>
              <li className='list'><a className='list-link' href="#contact">Contact</a></li>
              <li className='list'><a className='list-link' href="#about">About</a></li>
            </ul>
			
		
				
				<DB />
					
         </div>
     
	 );
   }
}

export default App;