import React from 'react';
import UpLoad from './upload.jsx';
import FileChooser from './filechooser.jsx';

//import TemplateDetailsList from './TemplateDetailsList.jsx';

class FilesList extends React.Component {
	
		constructor(props){
		super(props);
		
		} 
		
		

 render() {
	var file=[];
		for(var i=0;i<this.props.num;i++){
			file.push(<FileChooser key={i} />);
			}
										
		var uploadfile=[];
		if(this.props.num!= 0)
		{
		uploadfile.push(<UpLoad />); 
 }
	if(this.props.num==0){
	 return (
			
			     <h3> no files selected </h3>
				 );
	}
 	if(this.props.num==1){
	 return (
			<div>
			{file}				  
					<br/>
									
					{uploadfile}
					</div>		
				 );
	}
	if(this.props.num==2){
	 return (
	 			<div>

			{file}				  
					<br/>
									
					{uploadfile}	
						</div>

				 );
	}
 if(this.props.num==3){ 
    return (
				<div>

		{file}				  
					<br/>
									
					{uploadfile}	
			
			</div>

			 );
}
		
	
   }
}

export default FilesList;
