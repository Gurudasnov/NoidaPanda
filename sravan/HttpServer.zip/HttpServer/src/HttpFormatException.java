public class HttpFormatException extends Exception {
	private static final long serialVersionUID = 837910846054497673L;

	public HttpFormatException() {
		// TODO Auto-generated constructor stub
	}

	public HttpFormatException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public HttpFormatException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public HttpFormatException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}