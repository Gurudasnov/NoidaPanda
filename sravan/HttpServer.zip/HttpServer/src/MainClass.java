import java.net.ServerSocket;
import java.net.Socket;

public class MainClass {
	ServerSocket ss;
	public static void main(String args[]) throws Exception{
		new MainClass().runServer();
	}
	public void runServer() throws Exception{
		System.out.println("Server started");
		ss=new ServerSocket(6001);
		acceptRequests();		
	}
	private void acceptRequests() throws Exception {
		while(true){
			Socket s = ss.accept();
			ConnectionHandler ch = new ConnectionHandler(s);
			ch.start();
		}
	}
	public void stopServer() throws Exception{
		ss.close();
		System.out.println("Terminated");
	}
}
