
public class StopingServer{
	public static void main(String args[]) throws Exception{
	MainClass mc = new MainClass();
	mc.stopServer();
	}
}
