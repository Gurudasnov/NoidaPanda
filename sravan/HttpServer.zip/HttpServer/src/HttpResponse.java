import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;

public class HttpResponse {
	HttpRequest req;
	DataOutputStream response;
	String root = "D:/root";
	public HttpResponse(HttpRequest request, BufferedWriter log ,DataOutputStream pw) throws IOException{
		req=request;
		String filename = req.filename1;
		log.write("[HttpResponse] START "+new Date(System.currentTimeMillis()));
		log.flush();
		System.out.println("Reading file-->"+filename);
		log.write("[HttpResponse] Reading file-->"+root + filename);
		log.flush();
		File f =new File(root + filename);
		try {
			String extension= "";
			int a = filename.lastIndexOf('.');
            if (a > 0) {
                extension = filename.substring(a+1);
            }
            if(extension.equals("png"))
            {
                FileInputStream fis = new FileInputStream(f);
                byte[] data = new byte[(int) f.length()];
                fis.read(data);
                fis.close();

                response = new DataOutputStream(pw);
                response.writeBytes("HTTP/1.0 200 OK\r\n");
                response.writeBytes("Content-Type: image/png\r\n");
                response.writeBytes("Content-Length: " + data.length);
                response.writeBytes("\r\n\r\n");
                response.write(data);    	
            	            	
            }else if(extension.equals("jpg"))
                {
                FileInputStream fis = new FileInputStream(f);
                byte[] data = new byte[(int) f.length()];
                fis.read(data);
                fis.close();

                response = new DataOutputStream(pw);
                response.writeBytes("HTTP/1.0 200 OK\r\n");
                response.writeBytes("Content-Type: image/jpg\r\n");
                response.writeBytes("Content-Length: " + data.length);
                response.writeBytes("\r\n\r\n");
                response.write(data);
   
                }else if(extension.equals("css"))
                {
                FileInputStream fis = new FileInputStream(f);
                byte[] data = new byte[(int) f.length()];
                fis.read(data);
                fis.close();

                response = new DataOutputStream(pw);
                response.writeBytes("HTTP/1.0 200 OK\r\n");
                response.writeBytes("Content-Type: text/css\r\n");
                response.writeBytes("Content-Length: " + data.length);
                response.writeBytes("\r\n\r\n");
                response.write(data);
   
                }else
            {
                	FileInputStream fis = new FileInputStream(f);
                    byte[] data = new byte[(int) f.length()];
                    fis.read(data);
                    fis.close();
             response = new DataOutputStream(pw);
			response.writeBytes("HTTP/1.1 200 \r\n");
			response.writeBytes("Server : Our Java Server/1.0 \r\n");
//			response.writeBytes("Content-Type: text/html; charset=utf Content-Type: multipart/form-data; boundary=something r\n");
//			response.writeBytes("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8 r\n");
			response.writeBytes(" Content-Length : "+ f.length() + "\r\n");
			response.writeBytes("\r\n");
			
			FileReader fr = new FileReader(f);
			BufferedReader br=new BufferedReader(fr);  
			int s;
			String file="";
			while ((s = br.read()) != -1)
			{
				file += (char) s;
			}
			String filelines[] = file.split("\n");
			if(file.contains("^^")&&filename.contains(".html")){
			for(int i=0;i<filelines.length;i++){
				
			if(filelines[i].contains("^^")){
				int id1 = filelines[i].indexOf("^^",0);
				int id2 = filelines[i].indexOf("^^",id1+1);
				String attr = filelines[i].substring(id1, id2+2);
				String attr1= attr.substring(2, attr.length()-2);
				String rattr= req.getattributes().get(attr1);
				if(rattr.contains("+"))
					rattr=rattr.replace("+", " ");
				if(rattr.contains("%40"))
					rattr=rattr.replace("%40", "@");
				file=file.replace(attr,rattr);
			}
			}
			response.writeBytes(file);
			}
			else
				response.write(data);;
				br.close();
				fis.close();
            }
		} catch (FileNotFoundException e) {
			response.writeBytes("404 ERROR");
			e.printStackTrace();
		} catch (Exception ex){
			ex.printStackTrace();
		}
		finally {
			log.write("[HttpResponse] END "+new Date(System.currentTimeMillis()));
		}
	}
}
