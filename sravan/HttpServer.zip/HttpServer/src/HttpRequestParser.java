
import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.Hashtable;

public class HttpRequestParser {

    private String _requestLine;
    private Hashtable<String, String> _requestHeaders;
    private StringBuffer _messagetBody;

    public HttpRequestParser() {
        _requestHeaders = new Hashtable<String, String>();
        _messagetBody = new StringBuffer();
    }
    public void parseRequest(String request) throws IOException, HttpFormatException {
        BufferedReader reader = new BufferedReader(new StringReader(request));

        setRequestLine(reader.readLine());
        String header = reader.readLine();
        while (header.length() > 0) {
            appendHeaderParameter(header);
            header = reader.readLine();
        }
        String bodyLine = reader.readLine();
        while (bodyLine != null) {
            appendMessageBody(bodyLine);
            bodyLine = reader.readLine();
        }
    }
    public String getRequestLine() {
        return _requestLine;
    }
    private void setRequestLine(String requestLine) throws HttpFormatException {
        if (requestLine == null || requestLine.length() == 0) {
            throw new HttpFormatException("Invalid Request-Line: " + requestLine);
        }
        _requestLine = requestLine;
    }

    private void appendHeaderParameter(String header) throws HttpFormatException {
        int idx = header.indexOf(":");
        if (idx == -1) {
            throw new HttpFormatException("Invalid Header Parameter: " + header);
        }
        _requestHeaders.put(header.substring(0, idx), header.substring(idx + 1, header.length()));
    }
    public String getMessageBody() {
        return _messagetBody.toString();
    }
    private void appendMessageBody(String bodyLine) {
        _messagetBody.append(bodyLine).append("\r\n");
    }
    public String getHeaderParam(String headerName){
        return _requestHeaders.get(headerName);
    }
    public String readHashtable()
    {
    	return _requestHeaders.toString();
    }
    public String postFileName(String request){
    	String lines[] = request.split("\n");
		String filename = lines[0].split(" ")[1];
		return filename;
    }
    public String getMethod(String request){
    	String lines[] = request.split("\n");
		String method = lines[0].split(" ")[0];
		return method;
    }
    public String getFilename(String request){
    	String filename="";
    	String lines[] = request.split("\n");
		String getline = lines[0].split(" ")[1];
		if(getline.contains("?")){
			filename= getline.substring(0, getline.indexOf("?"));
		}
		else
			filename= getline.substring(0, getline.length());
		return filename;
    }
    public String getGetBody(String request){
    	String lines[] = request.split("\n");
		String getline = lines[0].split(" ")[1];
		String body = getline.substring(getline.indexOf("?")+1, getline.length());
		System.out.println(body);
		return body;
    }
}