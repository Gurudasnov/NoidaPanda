package activator;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
@ApplicationPath("/ldap")
public class JaxRsActivator extends Application
{
}