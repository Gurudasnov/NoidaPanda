var config = {

   entry: './view/main.js',

   output: {
     path: __dirname,
      filename: './view/index.js',
   },

   devServer: {
      inline: true,
      port: 80
   },

   module: {
      loaders: [
         {
            test: /\.(js|jsx)$/,
            exclude: /(node_modules|bower_components)/,

            loader: 'babel-loader',

            query: 
			{
               presets: ['es2015', 'react']
            }
         },
		  { test: /\.css-loader$/, loader: "style-loader" }

      ]
	}
}

module.exports = config;
