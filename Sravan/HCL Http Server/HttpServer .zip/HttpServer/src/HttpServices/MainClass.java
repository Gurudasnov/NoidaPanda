package HttpServices;
import java.net.ServerSocket;
import java.net.Socket;

public class MainClass {
	ServerSocket ss;
	public static void main(String args[]) throws Exception{
		new MainClass().runServer();
		Runtime r=Runtime.getRuntime(); 
		r.addShutdownHook(new ShutdownServer());  
	}
	public String runServer() throws Exception{
		ss=new ServerSocket(6001);
		System.out.println("Server Started");
		acceptRequests();
		return "Server started";	
	}
	private void acceptRequests() throws Exception {
		while(true){
			Socket s = ss.accept();
			ConnectionHandler ch = new ConnectionHandler(s);
			ch.start();
		}
	}
	public String stopServer() throws Exception{
		ss.close();
		System.out.println("Server Terminated");
		return "Server Terminated";
	}
}
