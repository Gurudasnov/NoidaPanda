package HttpServices;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ConnectionHandler extends Thread {
	
	Socket s;
	DataOutputStream pw;
	BufferedReader br;
	BufferedWriter log;
	static int count=0;
	
	public ConnectionHandler(Socket s) throws Exception{
		this.s = s;
		br = new BufferedReader (new InputStreamReader(s.getInputStream()));
		pw = new DataOutputStream(s.getOutputStream());
	}
	public void run(){
		count++;
//		System.out.println("Current thread is "+Thread.currentThread().getName());
		try {
			log = new BufferedWriter(new PrintWriter("D:\\webserver\\log\\"+Thread.currentThread().getName()));
		String reqS = "";
				while(br.ready() || reqS.length() == 0){
					reqS += (char)br.read();
				}
//				System.out.println(reqS);
		log.write("Browser output\n");
		log.flush();
		log.write("---------------START------------------\n");
		log.flush();
		log.write(reqS);
		log.flush();
		log.write("---------------END--------------------\n");
		log.flush();
		HttpRequest req = new HttpRequest(reqS);
		new HttpResponse(req, log , pw);
		pw.close();
		br.close();
		s.close();
//		System.out.println("Number of threads running is "+count);
		count--;
		} catch (IOException e) {
			e.printStackTrace();
		} catch (HttpFormatException e) {
			e.printStackTrace();
		}
	}
}
