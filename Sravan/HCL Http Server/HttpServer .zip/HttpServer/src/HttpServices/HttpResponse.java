package HttpServices;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Date;

import javax.ws.rs.core.Response;

import org.json.JSONObject;

public class HttpResponse {
	HttpRequest req;
	DataOutputStream response;
	String root = "D:/root";
	String extension= "";
	String Restfilename;
	String Resturlpath;
	String Restclasspath;
	String Restmethodpath;
	String classname="";
	String packagename="";
	String pathvalue;
	String consumevalue;
	String str;
	
	
	public HttpResponse(HttpRequest request, BufferedWriter log ,final DataOutputStream pw) throws IOException{
		
		req=request;
		String filename = req.filename1;
		log.write("[HttpResponse] START "+new Date(System.currentTimeMillis()));
		log.flush();
		System.out.println("Reading file-->"+filename);
		log.write("[HttpResponse] Reading file-->"+root + filename);
		log.flush();
		File f =new File(root + filename);
		try {
			
			if((filename.contains(".")== false)&&(filename.contains("rest"))){
				String Restname[]=filename.split("/");
				Restfilename=Restname[1];
				Resturlpath=Restname[2];
				Restclasspath=Restname[3];
				Restmethodpath=Restname[4];
				System.out.println(Restfilename);
				File f1= new File(root +"/Rest/alahari.xml");
				FileReader fr1 = new FileReader(f1);
				BufferedReader br1=new BufferedReader(fr1);  
				int s1;
				String file1="";
				while ((s1 = br1.read()) != -1){
					file1 += (char) s1;
				}
				String filelines1[] = file1.split("\n");
				
				for(int y=0;y<filelines1.length;y++){
					if(filelines1[y].contains("<path>")){
						int id3 = filelines1[y].indexOf(">",0);
						int id4 = filelines1[y].indexOf("<",id3);
						String path = filelines1[y].substring(id3+1, id4);
						if(filename.equalsIgnoreCase(path)&&filelines1[y+1].contains("<package>")&&filelines1[y+2].contains("<class>")){
							int id5 = filelines1[y+1].indexOf(">",0);
							int id6 = filelines1[y+1].indexOf("<",id5);
							int id7 = filelines1[y+2].indexOf(">",0);
							int id8 = filelines1[y+2].indexOf("<",id7);
							packagename = filelines1[y+1].substring(id5+1, id6);
							classname = filelines1[y+2].substring(id7+1, id8);
						}
					}
				}
				response = new DataOutputStream(pw);
				response.writeBytes("HTTP/1.1 200 \r\n");
				response.writeBytes("Content-Type: text/html \r\n");
				response.writeBytes("\r\n\r\n");
				ClassPathClass.addFile(root+"/Rest/"+Restfilename+".jar");
				System.out.println(packagename+"."+classname);
				Class<?> clazz = Class.forName(packagename+"."+classname);
				Object object = clazz.newInstance();
				Method[] m=object.getClass().getMethods();
				String body = req.body;
			    JSONObject jsonObj = new JSONObject(body);

//				System.out.println(body);
//				System.out.println(jsonObj.toString());
//				int idx = body.indexOf("="); 
//				String attr=body.substring(idx+1,body.length());
//				System.out.println(attr);
				for(int r=0;r<m.length;r++){
					Annotation[] atn = m[r].getAnnotations();
					for(int a=0;a<atn.length;a++){
						str=atn[a].toString();
//						System.out.println(str);
						if(str.contains("Path")){
						pathvalue = str.substring(str.indexOf("=")+1, str.indexOf(")"));
//						System.out.println(pathvalue);
						}
						if(str.contains("Consumes")){
							consumevalue = str.substring(str.indexOf("=")+1, str.indexOf(")"));
							System.out.println(consumevalue);
							if((Restmethodpath.equalsIgnoreCase(pathvalue))&&(consumevalue.equalsIgnoreCase("[application/json]"))){
								String strg =(String) m[r].invoke(object,jsonObj);								
								response.writeBytes("<h3>"+strg+"</h3>");
							}
						}
						}if(Restmethodpath.equalsIgnoreCase(pathvalue)){
								String strg =(String) m[r].invoke(object,body);								
								response.writeBytes("<h3>"+strg+"</h3>");
					}
				}
			}
			else{
			int a = filename.lastIndexOf('.');
            if (a > 0) {
                extension = filename.substring(a+1);
            }
            if(extension.equals("png"))
            {
                FileInputStream fis = new FileInputStream(f);
                byte[] data = new byte[(int) f.length()];
                fis.read(data);
                fis.close();

                response = new DataOutputStream(pw);
                response.writeBytes("HTTP/1.0 200 OK\r\n");
                response.writeBytes("Content-Type: image/png\r\n");
                response.writeBytes("Content-Length: " + data.length);
                response.writeBytes("\r\n\r\n");
                response.write(data);    	
            	            	
            }else if(extension.equals("jpg"))
                {
                FileInputStream fis = new FileInputStream(f);
                byte[] data = new byte[(int) f.length()];
                fis.read(data);
                fis.close();

                response = new DataOutputStream(pw);
                response.writeBytes("HTTP/1.0 200 OK\r\n");
                response.writeBytes("Content-Type: image/jpg\r\n");
                response.writeBytes("Content-Length: " + data.length);
                response.writeBytes("\r\n\r\n");
                response.write(data);
   
                }else if(extension.equals("css"))
                {
                FileInputStream fis = new FileInputStream(f);
                byte[] data = new byte[(int) f.length()];
                fis.read(data);
                fis.close();

                response = new DataOutputStream(pw);
                response.writeBytes("HTTP/1.0 200 OK\r\n");
                response.writeBytes("Content-Type: text/css\r\n");
                response.writeBytes("Content-Length: " + data.length);
                response.writeBytes("\r\n\r\n");
                response.write(data);
   
                }else if(extension.equals("js"))
                {
                FileInputStream fis = new FileInputStream(f);
                byte[] data = new byte[(int) f.length()];
                fis.read(data);
                fis.close();

                response = new DataOutputStream(pw);
                response.writeBytes("HTTP/1.0 200 OK\r\n");
                response.writeBytes("Content-Type: text/html\r\n");
                response.writeBytes("Content-Length: " + data.length);
                response.writeBytes("\r\n\r\n");
                response.write(data);
   
                }else
            {
                	FileInputStream fis = new FileInputStream(f);
                    byte[] data = new byte[(int) f.length()];
                    fis.read(data);
                    fis.close();
            response = new DataOutputStream(pw);
			response.writeBytes("HTTP/1.1 200 \r\n");
			response.writeBytes("Server : Our Java Server/1.0 \r\n");
//			response.writeBytes("Content-Type: text/html; charset=utf Content-Type: multipart/form-data; boundary=something r\n");
//			response.writeBytes("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8 r\n");
			response.writeBytes(" Content-Length : "+ f.length() + "\r\n");
			response.writeBytes("\r\n");
			
			FileReader fr = new FileReader(f);
			BufferedReader br=new BufferedReader(fr);  
			int s;
			String file="";
			while ((s = br.read()) != -1)
			{
				file += (char) s;
			}
			String filelines[] = file.split("\n");
			if(file.contains("^^")&&filename.contains(".html")){
			for(int i=0;i<filelines.length;i++){
				
			if(filelines[i].contains("^^")){
				int id1 = filelines[i].indexOf("^^",0);
				int id2 = filelines[i].indexOf("^^",id1+1);
				String attr = filelines[i].substring(id1, id2+2);
				String attr1= attr.substring(2, attr.length()-2);
				String rattr= req.getattributes().get(attr1);
				if(rattr.contains("+"))
					rattr=rattr.replace("+", " ");
				if(rattr.contains("%40"))
					rattr=rattr.replace("%40", "@");
				file=file.replace(attr,rattr);
			}
			}
			response.writeBytes(file);
			}
			else
				response.write(data);;
				br.close();
				fis.close();
            }
			}
			
		} catch (FileNotFoundException e) {
			 e.printStackTrace();
		} catch (Exception ex){
			ex.printStackTrace();
		}
		finally {
			log.write("[HttpResponse] END "+new Date(System.currentTimeMillis()));
		}
	}
}
