package HttpServices;
import java.io.IOException;
import java.util.Hashtable;

public class HttpRequest 
{
	String filename1="";
	String method="";
	String body;
	String St[] = new String[10];
	String root = "D:/root";
	private Hashtable<String, String> attributes;
	public Hashtable<String, String> getattributes(){
		return attributes;
	}
	public HttpRequest(String request) throws IOException, HttpFormatException, NullPointerException
	{
		HttpRequestParser hrp = new HttpRequestParser();
		method=hrp.getMethod(request);
		attributes = new Hashtable<String, String>();
		if(method.equalsIgnoreCase("POST")){
			filename1=hrp.postFileName(request);
			hrp.parseRequest(request);
			body = hrp.getMessageBody();
			if(body.contains("&")){
				String bodydata[] = body.split("&");
				for(int i=0;i<bodydata.length;i++)
				{
					int idx = bodydata[i].indexOf("="); 
					attributes.put(bodydata[i].substring(0,idx),bodydata[i].substring(idx+1,bodydata[i].length()));
				}
			}
		}
		else if(method.equalsIgnoreCase("GET")){
			filename1 = hrp.getFilename(request);
			if(request.contains("?"))
			body = hrp.getGetBody(request);
			if(request.contains("?")){
			if(body.contains("&")){
				String bodydata[] = body.split("&");
				for(int i=0;i<bodydata.length;i++)
				{
					int idx = bodydata[i].indexOf("="); 
					attributes.put(bodydata[i].substring(0,idx),bodydata[i].substring(idx+1,bodydata[i].length()));
				}
			}
		}
		}
	}	
}
