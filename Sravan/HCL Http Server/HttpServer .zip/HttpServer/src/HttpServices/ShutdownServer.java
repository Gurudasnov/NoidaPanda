package HttpServices;

public class ShutdownServer extends Thread {
	
		public void run(){
			MainClass mc = new MainClass();
			try {
				mc.stopServer();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
}
